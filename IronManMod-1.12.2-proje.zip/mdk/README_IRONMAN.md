# Iron Man Mod - Minecraft 1.12.2 (Forge 14.23.5.2864)

## JAR nasıl alınır (3 adım)
1. **JDK 8** kur (Adoptium Temurin 8). Forge 1.12.2 ForgeGradle'ı Java 8 ister.
2. Bu klasörde **`build.bat`** dosyasına çift tıkla (Linux/Mac: `./build.sh`).
   İlk seferde Forge ve Minecraft dosyalarını indirir, 10-20 dk sürebilir.
3. Jar: **`build/libs/IronManMod-1.0.0.jar`** -> Forge 1.12.2 `mods` klasörüne at.

Sorun çıkarsa: `gradlew.bat clean build` ya da `gradlew.bat setupDecompWorkspace` dene.
IntelliJ için: `gradlew genIntellijRuns`, Eclipse için: `gradlew genEclipseRuns`.

## Zırhlar (her biri 4 parça: kask, göğüslük, pantolon, bot)
| Takım | Özellikler |
|---|---|
| Mark I | Alev makinesi, bilek füzesi (uçuş yok, ağır zırh) |
| Mark III | Uçuş, repulsor, unibeam, gece görüşü |
| Mark VII | + füze yağmuru, hedef kilitleme, iniş şok dalgası |
| Mark XLII | + alev makinesi |
| Mark XLVI | + enerji kalkanı |
| Mark L | + nano onarım (can ve zırh yeniler) |
| Mark LXXXV | Hepsi, en hızlı, en yüksek enerji ve hasar |

Takım, 4 parçanın **aynı** Mark'tan olmasıyla aktif olur. Enerji göğüslükte tutulur.

## Tarifler (tüm tarifler JSON, JEI ile görülebilir)
- Ark Reaktörü: altın + redstone + glowstone
- Nano Plaka: elmas + altın + demir bloğu (2 adet verir)
- Zırh malzemesi: Mk I demir, Mk III altın, Mk VII elmas, Mk XLII zümrüt, Mk XLVI obsidyen,
  Mk L nano plaka, Mk LXXXV nano plaka (göğüslükte ayrıca Nether yıldızı)
- Göğüslükler ark reaktörü ister.

## Tuşlar (Kontroller > "Iron Man Modu" kategorisinden değiştirilebilir)
| Tuş | İşlev |
|---|---|
| R | Uçuş aç/kapat |
| F | Yüz maskesi aç/kapat (animasyonlu) |
| V | Repulsor ateşi (basılı tut) |
| G | Unibeam (basılı tut, şarj olup ateşlenir) |
| B | Füze yağmuru |
| X | Hızlandırıcı / after-burner (basılı tut, ses duvarı efekti) |
| Z | Hover (havada asılı hassas mod) |
| U | Zırh giyme sinematiği (envanterdeki tam takımı giyer) |
| N | Gece görüşü |
| K | Hedef kilitleme |
| Y | Alev makinesi (basılı tut) |
| C | Sinematik orbit kamera |
| H | HUD modu: tam / minimal / kapalı |

Uçuşta: W/A/S/D yön, Space yukarı, Shift aşağı, fare yönü belirler.
HUD'daki sağ panel her özelliğin **güncel tuşunu** gösterir (tuşu değiştirirsen o da değişir).

## HUD (J.A.R.V.I.S.)
Yüz maskesi kapalıyken açılır (boot animasyonu ile): pusula, ark reaktörü enerji halkası,
zırh/can çubukları, hız/irtifa, eğim merdiveni, radar, düşman kutuları ve kilitli hedef bilgisi,
J.A.R.V.I.S. mesaj günlüğü, düşük enerji uyarısı, hasar flaşı.

## Sinematik sahneler
- **Zırh giyme (U):** letterbox, kamera orbit, parçalar sırayla vücuda uçar, yüz maskesi açılıp kapanır.
- **Süper kahraman inişi:** yüksekten inişte şok dalgası, toz/blok partikülleri, kamera sarsıntısı, hasar alanı.
- **Uçuş kalkışı, ses duvarı konisi, unibeam şarjı** (FOV daralır, ekran sallanır, geri tepme).
- **C tuşu:** serbest sinematik orbit kamera.

## Ayarlar
`config/ironmanmod.cfg`: blok hasarı, hasar/enerji çarpanları, sinematik efektleri aç/kapa.

## Bilinen sınırlar (dürüst not)
- Zırh görünümü, vanilla biped modeline eklenen kutu parçalarıyla yapılır (tam özel 3D model değil).
  Dokular otomatik üretilmiş yer tutucudur; `assets/ironmanmod/textures/models/armor/*.png`
  (64x64) dosyalarını kendi dokularınla değiştirebilirsin. UV haritası: kask 0,0 / yüz plakası 0,32 /
  ark reaktörü 24,32 / avuç 24,40 / bot iticisi 40,40 / omuz 0,44.
- Sesler vanilla seslerdir. Özel ses için `sounds.json` ekleyip `ServerHandler` içindeki `SoundEvents`'i değiştir.
- Oyunda test edilmeden teslim edilmiştir; derleme/çalışma sırasında çıkan hatalar kolay düzeltilir, hatayı iletirsen düzeltirim.
