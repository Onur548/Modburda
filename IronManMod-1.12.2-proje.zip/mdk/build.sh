#!/bin/sh
# Iron Man Mod - derleme (Linux/Mac). JDK 8 gerekir.
./gradlew build && echo "Jar: build/libs/IronManMod-1.0.0.jar"
