@echo off
REM Iron Man Mod - tek tikla derleme (Windows). JDK 8 gerekir (Temurin 8 onerilir).
REM Ilk calistirmada Forge + Minecraft indirilir (10-20 dk surebilir, internet gerekir).
echo Java surumu:
java -version
call gradlew.bat build
echo.
echo Bitti. Jar dosyasi: build\libs\IronManMod-1.0.0.jar
pause
