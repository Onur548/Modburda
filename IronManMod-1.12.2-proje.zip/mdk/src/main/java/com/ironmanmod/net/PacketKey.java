package com.ironmanmod.net;

import com.ironmanmod.server.ServerHandler;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketKey implements IMessage {
    public enum Action { FLIGHT, FACE, REPULSOR, UNIBEAM, MISSILES, BOOST, HOVER, SUITUP, VISION, LOCKON, FLAME }

    public int action;
    public boolean down;

    public PacketKey() {}

    public PacketKey(Action a, boolean down) {
        this.action = a.ordinal();
        this.down = down;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        action = buf.readByte();
        down = buf.readBoolean();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(action);
        buf.writeBoolean(down);
    }

    public static class Handler implements IMessageHandler<PacketKey, IMessage> {
        @Override
        public IMessage onMessage(PacketKey m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            if (m.action < 0 || m.action >= Action.values().length) return null;
            final Action a = Action.values()[m.action];
            final boolean down = m.down;
            p.getServerWorld().addScheduledTask(() -> ServerHandler.handleAction(p, a, down));
            return null;
        }
    }
}
