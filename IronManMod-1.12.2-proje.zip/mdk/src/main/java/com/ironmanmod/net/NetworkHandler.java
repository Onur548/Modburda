package com.ironmanmod.net;

import com.ironmanmod.IronManMod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static final SimpleNetworkWrapper NET = NetworkRegistry.INSTANCE.newSimpleChannel(IronManMod.MODID);

    public static void init() {
        NET.registerMessage(PacketKey.Handler.class, PacketKey.class, 0, Side.SERVER);
        NET.registerMessage(PacketState.Handler.class, PacketState.class, 1, Side.CLIENT);
        NET.registerMessage(PacketEffect.Handler.class, PacketEffect.class, 2, Side.CLIENT);
    }
}
