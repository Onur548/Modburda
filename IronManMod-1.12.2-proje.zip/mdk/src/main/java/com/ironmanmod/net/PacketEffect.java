package com.ironmanmod.net;

import com.ironmanmod.IronManMod;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketEffect implements IMessage {
    public static final int JARVIS = 0, BEAM = 1, LANDING = 2, SUITUP = 3, FLIGHT_START = 4, SHAKE = 5;

    public int type, id, color;
    public double x, y, z, a, b, c;
    public String s = "";

    public PacketEffect() {}

    public PacketEffect(int type) {
        this.type = type;
    }

    public static PacketEffect jarvis(String key) {
        PacketEffect e = new PacketEffect(JARVIS);
        e.s = key;
        return e;
    }

    public PacketEffect pos(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }

    public PacketEffect vec(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
        return this;
    }

    public PacketEffect id(int id) {
        this.id = id;
        return this;
    }

    public PacketEffect color(int c) {
        this.color = c;
        return this;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        type = buf.readByte();
        id = buf.readInt();
        color = buf.readInt();
        x = buf.readDouble();
        y = buf.readDouble();
        z = buf.readDouble();
        a = buf.readDouble();
        b = buf.readDouble();
        c = buf.readDouble();
        s = ByteBufUtils.readUTF8String(buf);
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(type);
        buf.writeInt(id);
        buf.writeInt(color);
        buf.writeDouble(x);
        buf.writeDouble(y);
        buf.writeDouble(z);
        buf.writeDouble(a);
        buf.writeDouble(b);
        buf.writeDouble(c);
        ByteBufUtils.writeUTF8String(buf, s);
    }

    public static class Handler implements IMessageHandler<PacketEffect, IMessage> {
        @Override
        public IMessage onMessage(PacketEffect m, MessageContext ctx) {
            IronManMod.proxy.handleEffect(m);
            return null;
        }
    }
}
