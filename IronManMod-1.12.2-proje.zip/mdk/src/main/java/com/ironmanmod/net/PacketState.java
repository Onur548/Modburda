package com.ironmanmod.net;

import com.ironmanmod.IronManMod;
import com.ironmanmod.SuitData;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

import java.util.UUID;

public class PacketState implements IMessage {
    public UUID id;
    public int suit = -1, bits, energy, maxEnergy, lockTarget, charge, beamCd, missileCd;

    public PacketState() {}

    public PacketState(UUID id, SuitData d) {
        this.id = id;
        this.suit = d.suit == null ? -1 : d.suit.ordinal();
        this.bits = d.bits();
        this.energy = (int) d.energy;
        this.maxEnergy = d.maxEnergy;
        this.lockTarget = d.lockTarget;
        this.charge = d.unibeamCharge;
        this.beamCd = d.beamCooldown;
        this.missileCd = d.missileCooldown;
    }

    @Override
    public void fromBytes(ByteBuf b) {
        id = new UUID(b.readLong(), b.readLong());
        suit = b.readByte();
        bits = b.readShort();
        energy = b.readInt();
        maxEnergy = b.readInt();
        lockTarget = b.readInt();
        charge = b.readByte();
        beamCd = b.readShort();
        missileCd = b.readShort();
    }

    @Override
    public void toBytes(ByteBuf b) {
        b.writeLong(id.getMostSignificantBits());
        b.writeLong(id.getLeastSignificantBits());
        b.writeByte(suit);
        b.writeShort(bits);
        b.writeInt(energy);
        b.writeInt(maxEnergy);
        b.writeInt(lockTarget);
        b.writeByte(charge);
        b.writeShort(beamCd);
        b.writeShort(missileCd);
    }

    public static class Handler implements IMessageHandler<PacketState, IMessage> {
        @Override
        public IMessage onMessage(PacketState m, MessageContext ctx) {
            IronManMod.proxy.handleState(m);
            return null;
        }
    }
}
