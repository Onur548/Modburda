package com.ironmanmod;

import net.minecraft.entity.player.EntityPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Sunucu tarafi oyuncu takim durumlari. */
public class SuitManager {
    private static final Map<UUID, SuitData> SERVER = new HashMap<>();

    public static SuitData server(EntityPlayer p) {
        return SERVER.computeIfAbsent(p.getUniqueID(), k -> new SuitData());
    }

    public static SuitData peek(UUID id) {
        return SERVER.get(id);
    }

    public static void remove(UUID id) {
        SERVER.remove(id);
    }
}
