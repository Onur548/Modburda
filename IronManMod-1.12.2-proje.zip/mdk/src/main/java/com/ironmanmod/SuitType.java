package com.ironmanmod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;

import java.util.EnumSet;

public enum SuitType {
    //        id       isim          dayanim  [bot,pant,gogus,kask]   tough enerji  ucusHizi repDmg beamDmg regen  hudRenk
    MARK1("mark1", "Mark I", 30, new int[]{3, 6, 8, 3}, 3F, 4000, 0.0, 0F, 0F, 0.02, 0xFFB347,
            Feature.FLAMETHROWER, Feature.MISSILES),
    MARK3("mark3", "Mark III", 34, new int[]{2, 5, 7, 3}, 2F, 8000, 0.9, 6F, 20F, 0.04, 0x8CE6FF,
            Feature.FLIGHT, Feature.REPULSOR, Feature.UNIBEAM, Feature.NIGHT_VISION),
    MARK7("mark7", "Mark VII", 37, new int[]{3, 6, 7, 3}, 2.5F, 12000, 1.1, 8F, 26F, 0.05, 0x6FD8FF,
            Feature.FLIGHT, Feature.REPULSOR, Feature.UNIBEAM, Feature.MISSILES, Feature.LOCKON,
            Feature.SHOCKWAVE, Feature.NIGHT_VISION),
    MARK42("mark42", "Mark XLII", 40, new int[]{3, 6, 8, 3}, 3F, 18000, 1.3, 10F, 32F, 0.06, 0x7FE0FF,
            Feature.FLIGHT, Feature.REPULSOR, Feature.UNIBEAM, Feature.MISSILES, Feature.LOCKON,
            Feature.SHOCKWAVE, Feature.NIGHT_VISION, Feature.FLAMETHROWER),
    MARK46("mark46", "Mark XLVI", 44, new int[]{3, 6, 8, 3}, 3.5F, 24000, 1.5, 12F, 40F, 0.08, 0x66E0FF,
            Feature.FLIGHT, Feature.REPULSOR, Feature.UNIBEAM, Feature.MISSILES, Feature.LOCKON,
            Feature.SHOCKWAVE, Feature.NIGHT_VISION, Feature.FLAMETHROWER, Feature.SHIELD),
    MARK50("mark50", "Mark L", 50, new int[]{3, 6, 8, 3}, 4F, 36000, 1.8, 14F, 50F, 0.15, 0x55D0FF,
            Feature.FLIGHT, Feature.REPULSOR, Feature.UNIBEAM, Feature.MISSILES, Feature.LOCKON,
            Feature.SHOCKWAVE, Feature.NIGHT_VISION, Feature.FLAMETHROWER, Feature.SHIELD, Feature.NANO_REGEN),
    MARK85("mark85", "Mark LXXXV", 66, new int[]{3, 6, 8, 3}, 5F, 60000, 2.2, 18F, 70F, 0.30, 0x7DF9FF,
            Feature.values());

    public static final SuitType[] VALUES = values();
    public static final EntityEquipmentSlot[] ARMOR_SLOTS = {
            EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST, EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET};

    public final String id, displayName;
    public final int durability, maxEnergy, hudColor;
    public final int[] reductions;
    public final float toughness, repulsorDamage, unibeamDamage;
    public final double flightSpeed, regen;
    private final EnumSet<Feature> features = EnumSet.noneOf(Feature.class);
    private ItemArmor.ArmorMaterial material;

    SuitType(String id, String displayName, int durability, int[] reductions, float toughness, int maxEnergy,
             double flightSpeed, float repDmg, float beamDmg, double regen, int hudColor, Feature... f) {
        this.id = id;
        this.displayName = displayName;
        this.durability = durability;
        this.reductions = reductions;
        this.toughness = toughness;
        this.maxEnergy = maxEnergy;
        this.flightSpeed = flightSpeed;
        this.repulsorDamage = repDmg;
        this.unibeamDamage = beamDmg;
        this.regen = regen;
        this.hudColor = hudColor;
        for (Feature x : f) features.add(x);
    }

    public boolean has(Feature f) {
        return features.contains(f);
    }

    public ItemArmor.ArmorMaterial material() {
        if (material == null) {
            material = EnumHelper.addArmorMaterial("IRONMAN_" + name(), IronManMod.MODID + ":" + id, durability,
                    reductions, 25, SoundEvents.ITEM_ARMOR_EQUIP_IRON, toughness);
        }
        return material;
    }

    /** Oyuncu ayni tipte 4 parca giymisse o takimi dondurur. */
    public static SuitType worn(EntityPlayer p) {
        SuitType found = null;
        for (EntityEquipmentSlot s : ARMOR_SLOTS) {
            ItemStack st = p.getItemStackFromSlot(s);
            if (!(st.getItem() instanceof ItemIronManArmor)) return null;
            ItemIronManArmor a = (ItemIronManArmor) st.getItem();
            if (a.armorType != s) return null;
            if (found == null) found = a.getSuit();
            else if (found != a.getSuit()) return null;
        }
        return found;
    }
}
