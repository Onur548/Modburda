package com.ironmanmod;

import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class ModItems {
    public static final List<Item> ALL = new ArrayList<>();
    public static final Item ARC_REACTOR = named(new Item(), "arc_reactor");
    public static final Item NANO_PLATE = named(new Item(), "nano_plate");
    private static final ItemIronManArmor[][] PIECES = new ItemIronManArmor[SuitType.VALUES.length][4];

    static {
        for (SuitType s : SuitType.VALUES) {
            for (EntityEquipmentSlot slot : SuitType.ARMOR_SLOTS) {
                ItemIronManArmor a = new ItemIronManArmor(s, slot);
                PIECES[s.ordinal()][3 - slot.getIndex()] = a;
                ALL.add(a);
            }
        }
    }

    private static Item named(Item i, String name) {
        i.setRegistryName(IronManMod.MODID, name);
        i.setUnlocalizedName(IronManMod.MODID + "." + name);
        i.setCreativeTab(ModTab.TAB);
        ALL.add(0, i);
        return i;
    }

    public static ItemIronManArmor piece(SuitType s, EntityEquipmentSlot slot) {
        return PIECES[s.ordinal()][3 - slot.getIndex()];
    }

    @SubscribeEvent
    public static void onRegister(RegistryEvent.Register<Item> e) {
        for (Item i : ALL) e.getRegistry().register(i);
    }
}
