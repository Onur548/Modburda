package com.ironmanmod;

import com.ironmanmod.net.NetworkHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = IronManMod.MODID, name = IronManMod.NAME, version = IronManMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class IronManMod {
    public static final String MODID = "ironmanmod";
    public static final String NAME = "Iron Man Mod";
    public static final String VERSION = "1.0.0";

    @SidedProxy(clientSide = "com.ironmanmod.client.ClientProxy", serverSide = "com.ironmanmod.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NetworkHandler.init();
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        proxy.init();
    }
}
