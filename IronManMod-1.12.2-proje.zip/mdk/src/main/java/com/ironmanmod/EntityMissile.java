package com.ironmanmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

public class EntityMissile extends Entity {
    private UUID ownerId;
    private int targetId = -1;
    private int age;
    private double speed = 0.5;
    private Vec3d dir = new Vec3d(0, 1, 0);
    public float power = 2.2F;

    public EntityMissile(World w) {
        super(w);
        setSize(0.25F, 0.25F);
        isImmuneToFire = true;
    }

    public EntityMissile(World w, EntityPlayer owner, int targetId, Vec3d dir, Vec3d pos, float power) {
        this(w);
        this.ownerId = owner.getUniqueID();
        this.targetId = targetId;
        this.dir = dir.normalize();
        this.power = power;
        setPosition(pos.x, pos.y, pos.z);
        motionX = this.dir.x * 0.3;
        motionY = this.dir.y * 0.3 + 0.25;
        motionZ = this.dir.z * 0.3;
    }

    @Override
    protected void entityInit() {}

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {}

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {}

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote) {
            world.spawnParticle(EnumParticleTypes.FLAME, posX, posY, posZ, 0, 0, 0);
            world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, posX, posY, posZ, 0, 0, 0);
            world.spawnParticle(EnumParticleTypes.FIREWORKS_SPARK, posX, posY, posZ,
                    (rand.nextDouble() - 0.5) * 0.1, (rand.nextDouble() - 0.5) * 0.1, (rand.nextDouble() - 0.5) * 0.1);
            return;
        }
        age++;
        EntityPlayer owner = ownerId == null ? null : world.getPlayerEntityByUUID(ownerId);
        if (ownerId == null || age > 120) {
            detonate(owner);
            return;
        }
        speed = Math.min(1.4, 0.5 + age * 0.05);
        Vec3d vel = new Vec3d(motionX, motionY, motionZ);
        Vec3d cur = vel.lengthSquared() < 1e-4 ? dir : vel.normalize();
        Vec3d want = dir;
        double turn = 0.12;
        Entity t = targetId >= 0 ? world.getEntityByID(targetId) : null;
        if (t != null && t.isEntityAlive()) {
            want = new Vec3d(t.posX, t.posY + t.height * 0.5, t.posZ).subtract(posX, posY, posZ).normalize();
            turn = age < 5 ? 0.0 : 0.28;
        }
        Vec3d nd = cur.scale(1 - turn).add(want.scale(turn));
        nd = nd.lengthSquared() < 1e-6 ? cur : nd.normalize();
        motionX = nd.x * speed;
        motionY = nd.y * speed;
        motionZ = nd.z * speed;

        Vec3d from = new Vec3d(posX, posY, posZ);
        Vec3d to = from.add(motionX, motionY, motionZ);
        RayTraceResult hit = world.rayTraceBlocks(from, to, false, true, false);
        if (hit != null && hit.hitVec != null) {
            setPosition(hit.hitVec.x, hit.hitVec.y, hit.hitVec.z);
            detonate(owner);
            return;
        }
        for (Entity e : world.getEntitiesWithinAABBExcludingEntity(this,
                getEntityBoundingBox().expand(motionX, motionY, motionZ).grow(0.5))) {
            if (e instanceof EntityLivingBase && e != owner && e.isEntityAlive()) {
                detonate(owner);
                return;
            }
        }
        setPosition(to.x, to.y, to.z);
    }

    private void detonate(EntityPlayer owner) {
        world.createExplosion(owner, posX, posY, posZ, power, ModConfig.blockDamage);
        setDead();
    }
}
