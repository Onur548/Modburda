package com.ironmanmod;

import net.minecraftforge.common.config.Config;

@Config(modid = IronManMod.MODID, name = "ironmanmod")
public class ModConfig {
    @Config.Comment("Fuze, Unibeam ve inis patlamalari bloklari kirsin mi?")
    public static boolean blockDamage = false;

    @Config.Comment("Tum silah hasari carpani")
    @Config.RangeDouble(min = 0.1, max = 10.0)
    public static double damageMultiplier = 1.0;

    @Config.Comment("Enerji tuketim carpani (0 = sonsuz enerji)")
    @Config.RangeDouble(min = 0.0, max = 10.0)
    public static double energyDrainMultiplier = 1.0;

    @Config.Comment("Enerji yenilenme carpani")
    @Config.RangeDouble(min = 0.0, max = 10.0)
    public static double regenMultiplier = 1.0;

    @Config.Comment("Sinematik kamera efektleri (sarsinti, FOV, letterbox, orbit kamera)")
    public static boolean cinematicEffects = true;
}
