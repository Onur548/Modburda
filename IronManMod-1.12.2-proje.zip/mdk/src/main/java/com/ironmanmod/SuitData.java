package com.ironmanmod;

/** Hem sunucuda hem istemcide kullanilan takim durumu. */
public class SuitData {
    public SuitType suit;
    public boolean faceClosed = true, flying, hover, boosting, repulsor, flame, unibeamHold, nightVision, lockOn;
    public double energy;
    public int maxEnergy;
    public int lockTarget = -1, unibeamCharge, repCooldown, beamCooldown, missileCooldown, missilesQueued;

    // sunucu
    public int suitUpTimer, faceTimer, lastBits = -1;
    public SuitType suitUpType;
    public double lastX, lastY, lastZ, speed;

    // istemci gorsel
    public float faceOpen, facePrev, lean, leanPrev;
    public double vx, vy, vz;
    public boolean wasFlying;

    public int bits() {
        int b = 0;
        if (faceClosed) b |= 1;
        if (flying) b |= 1 << 1;
        if (hover) b |= 1 << 2;
        if (boosting) b |= 1 << 3;
        if (repulsor) b |= 1 << 4;
        if (flame) b |= 1 << 5;
        if (unibeamHold) b |= 1 << 6;
        if (nightVision) b |= 1 << 7;
        if (lockOn) b |= 1 << 8;
        return b;
    }

    public void setBits(int b) {
        faceClosed = (b & 1) != 0;
        flying = (b & 2) != 0;
        hover = (b & 4) != 0;
        boosting = (b & 8) != 0;
        repulsor = (b & 16) != 0;
        flame = (b & 32) != 0;
        unibeamHold = (b & 64) != 0;
        nightVision = (b & 128) != 0;
        lockOn = (b & 256) != 0;
    }

    public void reset() {
        faceClosed = true;
        flying = hover = boosting = repulsor = flame = unibeamHold = nightVision = lockOn = false;
        lockTarget = -1;
        unibeamCharge = repCooldown = beamCooldown = missileCooldown = missilesQueued = 0;
        speed = 0;
    }

    public float faceOpen(float pt) {
        return facePrev + (faceOpen - facePrev) * pt;
    }

    public float lean(float pt) {
        return leanPrev + (lean - leanPrev) * pt;
    }
}
