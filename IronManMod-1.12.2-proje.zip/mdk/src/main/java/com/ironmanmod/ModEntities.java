package com.ironmanmod;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class ModEntities {
    @SubscribeEvent
    public static void onRegister(RegistryEvent.Register<EntityEntry> e) {
        e.getRegistry().register(EntityEntryBuilder.create()
                .entity(EntityMissile.class)
                .id(new ResourceLocation(IronManMod.MODID, "missile"), 0)
                .name(IronManMod.MODID + ".missile")
                .tracker(96, 1, true)
                .build());
    }
}
