package com.ironmanmod;

import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class ConfigHandler {
    @SubscribeEvent
    public static void onChanged(ConfigChangedEvent.OnConfigChangedEvent e) {
        if (e.getModID().equals(IronManMod.MODID)) {
            ConfigManager.sync(IronManMod.MODID, Config.Type.INSTANCE);
        }
    }
}
