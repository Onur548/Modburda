package com.ironmanmod.server;

import com.ironmanmod.*;
import com.ironmanmod.net.NetworkHandler;
import com.ironmanmod.net.PacketEffect;
import com.ironmanmod.net.PacketKey;
import com.ironmanmod.net.PacketState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;

import java.util.List;

@Mod.EventBusSubscriber(modid = IronManMod.MODID)
public class ServerHandler {
    public static final int REP_COST = 25, BEAM_COST = 500, MISSILE_COST = 200, BEAM_CHARGE = 35, SUITUP_TICKS = 60;

    // ------------------------------------------------------------------ tick
    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.world.isRemote) return;
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SuitData d = SuitManager.server(p);
        tickSuitUp(p, d);
        SuitType worn = SuitType.worn(p);
        boolean dirty = false;
        if (worn != d.suit) {
            changeSuit(p, d, worn);
            dirty = true;
        }
        if (d.suit != null) tickSuit(p, d);
        int bits = d.bits();
        if (dirty || (d.suit != null && (bits != d.lastBits || p.ticksExisted % 4 == 0))) {
            d.lastBits = bits;
            sendState(p, d);
        }
    }

    private static void sendState(EntityPlayerMP p, SuitData d) {
        PacketState m = new PacketState(p.getUniqueID(), d);
        ((WorldServer) p.world).getEntityTracker().sendToTrackingAndSelf(p, NetworkHandler.NET.getPacketFrom(m));
    }

    private static void changeSuit(EntityPlayerMP p, SuitData d, SuitType n) {
        if (d.suit != null) {
            setFlightAbility(p, false);
            if (d.nightVision) p.removePotionEffect(MobEffects.NIGHT_VISION);
            sound(p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.8F, 1.2F);
        }
        d.reset();
        d.suit = n;
        if (n != null) {
            d.maxEnergy = n.maxEnergy;
            d.energy = ItemIronManArmor.getEnergy(p.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
            d.lastX = p.posX;
            d.lastY = p.posY;
            d.lastZ = p.posZ;
            sound(p, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 1F, 0.8F);
            sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.8F, 1.4F);
            jarvis(p, "ironmanmod.jarvis.online");
        }
    }

    private static void tickSuit(EntityPlayerMP p, SuitData d) {
        SuitType s = d.suit;
        double dx = p.posX - d.lastX, dy = p.posY - d.lastY, dz = p.posZ - d.lastZ;
        d.speed = Math.sqrt(dx * dx + dy * dy + dz * dz);
        d.lastX = p.posX;
        d.lastY = p.posY;
        d.lastZ = p.posZ;

        if (d.faceTimer > 0 && --d.faceTimer == 0) {
            d.faceClosed = true;
            sound(p, SoundEvents.BLOCK_PISTON_CONTRACT, 0.7F, 1.6F);
            jarvis(p, "ironmanmod.jarvis.online");
        }
        if (d.repCooldown > 0) d.repCooldown--;
        if (d.beamCooldown > 0) d.beamCooldown--;
        if (d.missileCooldown > 0) d.missileCooldown--;

        double drain = 0;
        boolean busy = false;

        // ucus
        if (d.flying) {
            if (d.energy <= 0 || !s.has(Feature.FLIGHT)) {
                stopFlight(p, d);
                jarvis(p, "ironmanmod.jarvis.power_critical");
            } else {
                drain += 0.35 + d.speed * 2.5 + (d.boosting ? 2.5 : 0);
                p.fallDistance = 0;
                if (!p.capabilities.allowFlying) {
                    p.capabilities.allowFlying = true;
                    p.sendPlayerAbilities();
                }
                busy = true;
                if (p.ticksExisted % 6 == 0) sound(p, SoundEvents.ITEM_ELYTRA_FLYING, 0.25F, 1.6F);
            }
        } else {
            d.boosting = false;
        }

        // repulsor
        if (d.repulsor && s.has(Feature.REPULSOR) && d.repCooldown <= 0) {
            if (d.energy >= REP_COST) {
                fireRepulsor(p, d);
                busy = true;
            } else if (p.ticksExisted % 60 == 0) {
                jarvis(p, "ironmanmod.jarvis.low_energy");
            }
        }

        // unibeam
        if (d.unibeamHold && s.has(Feature.UNIBEAM) && d.beamCooldown <= 0) {
            if (d.energy >= BEAM_COST) {
                d.unibeamCharge++;
                busy = true;
                if (d.unibeamCharge % 7 == 1) sound(p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 1F, 0.5F + d.unibeamCharge * 0.03F);
                if (d.unibeamCharge >= BEAM_CHARGE) {
                    fireUnibeam(p, d);
                    d.unibeamCharge = 0;
                    d.beamCooldown = 100;
                    d.unibeamHold = false;
                }
            } else {
                d.unibeamHold = false;
                d.unibeamCharge = 0;
                jarvis(p, "ironmanmod.jarvis.low_energy");
            }
        } else if (!d.unibeamHold) {
            d.unibeamCharge = 0;
        }

        // fuzeler
        if (d.missilesQueued > 0 && p.ticksExisted % 3 == 0) {
            launchMissile(p, d, d.missilesQueued);
            d.missilesQueued--;
        }

        // alev
        if (d.flame && s.has(Feature.FLAMETHROWER)) {
            if (d.energy >= 3) {
                flame(p, d);
                drain += 3;
                busy = true;
            } else {
                d.flame = false;
            }
        }

        tickLock(p, d);

        // gece gorusu
        if (d.nightVision && s.has(Feature.NIGHT_VISION) && p.ticksExisted % 100 == 0) {
            p.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 260, 0, false, false));
        }

        // enerji
        if (!busy) d.energy += s.regen * 30 * ModConfig.regenMultiplier;
        if (s.has(Feature.NANO_REGEN)) {
            d.energy += s.regen * ModConfig.regenMultiplier;
            if (p.ticksExisted % 40 == 0 && p.getHealth() < p.getMaxHealth() && d.energy > 200) {
                p.heal(1F);
                d.energy -= 50;
            }
            if (p.ticksExisted % 100 == 0 && d.energy > 500) {
                for (EntityEquipmentSlot sl : SuitType.ARMOR_SLOTS) {
                    ItemStack st = p.getItemStackFromSlot(sl);
                    if (st.isItemDamaged()) st.setItemDamage(Math.max(0, st.getItemDamage() - 2));
                }
            }
        }
        d.energy -= drain * ModConfig.energyDrainMultiplier;
        if (d.energy < 0) d.energy = 0;
        if (d.energy > d.maxEnergy) d.energy = d.maxEnergy;

        if (p.ticksExisted % 40 == 0) {
            ItemIronManArmor.setEnergy(p.getItemStackFromSlot(EntityEquipmentSlot.CHEST), (int) d.energy);
        }
    }

    // ------------------------------------------------------------------ eylemler
    public static void handleAction(EntityPlayerMP p, PacketKey.Action a, boolean down) {
        SuitData d = SuitManager.server(p);
        if (a == PacketKey.Action.SUITUP) {
            if (down) trySuitUp(p, d);
            return;
        }
        if (d.suit == null) return;
        SuitType s = d.suit;
        switch (a) {
            case FLIGHT:
                if (!down) break;
                if (d.flying) {
                    stopFlight(p, d);
                } else if (!s.has(Feature.FLIGHT)) {
                    jarvis(p, "ironmanmod.jarvis.no_flight");
                } else if (d.energy < 100) {
                    jarvis(p, "ironmanmod.jarvis.low_energy");
                } else {
                    d.flying = true;
                    setFlightAbility(p, true);
                    sound(p, SoundEvents.ENTITY_FIREWORK_LAUNCH, 1.5F, 0.7F);
                    sound(p, SoundEvents.BLOCK_PISTON_EXTEND, 0.8F, 1.8F);
                    effect(p, new PacketEffect(PacketEffect.FLIGHT_START).id(p.getEntityId()).pos(p.posX, p.posY, p.posZ), 64);
                    jarvis(p, "ironmanmod.jarvis.flight_on");
                }
                break;
            case FACE:
                if (!down || d.faceTimer > 0) break;
                d.faceClosed = !d.faceClosed;
                sound(p, d.faceClosed ? SoundEvents.BLOCK_PISTON_CONTRACT : SoundEvents.BLOCK_PISTON_EXTEND, 0.7F, 1.7F);
                break;
            case REPULSOR:
                d.repulsor = down && s.has(Feature.REPULSOR);
                break;
            case UNIBEAM:
                if (down && s.has(Feature.UNIBEAM) && d.beamCooldown <= 0) d.unibeamHold = true;
                else d.unibeamHold = false;
                break;
            case MISSILES:
                if (!down || !s.has(Feature.MISSILES)) break;
                if (d.missileCooldown > 0 || d.missilesQueued > 0) break;
                if (d.energy < MISSILE_COST) {
                    jarvis(p, "ironmanmod.jarvis.low_energy");
                    break;
                }
                d.energy -= MISSILE_COST;
                d.missilesQueued = s == SuitType.MARK1 ? 2 : 6;
                d.missileCooldown = 100;
                jarvis(p, "ironmanmod.jarvis.missiles");
                break;
            case BOOST:
                d.boosting = down && d.flying;
                break;
            case HOVER:
                if (down && s.has(Feature.FLIGHT)) d.hover = !d.hover;
                break;
            case VISION:
                if (!down || !s.has(Feature.NIGHT_VISION)) break;
                d.nightVision = !d.nightVision;
                if (d.nightVision) p.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 260, 0, false, false));
                else p.removePotionEffect(MobEffects.NIGHT_VISION);
                break;
            case LOCKON:
                if (!down || !s.has(Feature.LOCKON)) break;
                d.lockOn = !d.lockOn;
                if (!d.lockOn) d.lockTarget = -1;
                jarvis(p, d.lockOn ? "ironmanmod.jarvis.lock_on" : "ironmanmod.jarvis.lock_off");
                break;
            case FLAME:
                d.flame = down && s.has(Feature.FLAMETHROWER);
                break;
            default:
                break;
        }
    }

    private static void stopFlight(EntityPlayerMP p, SuitData d) {
        d.flying = false;
        d.boosting = false;
        setFlightAbility(p, false);
        sound(p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.6F, 1.6F);
    }

    private static void setFlightAbility(EntityPlayerMP p, boolean on) {
        boolean allow = on || p.isCreative() || p.isSpectator();
        if (p.capabilities.allowFlying != allow) {
            p.capabilities.allowFlying = allow;
            if (!allow) p.capabilities.isFlying = false;
            p.sendPlayerAbilities();
        }
    }

    // ------------------------------------------------------------------ silahlar
    private static Vec3d aim(EntityPlayerMP p, SuitData d, Vec3d start) {
        if (d.lockOn && d.lockTarget >= 0) {
            Entity t = p.world.getEntityByID(d.lockTarget);
            if (t != null && t.isEntityAlive()) {
                return new Vec3d(t.posX, t.posY + t.height * 0.5, t.posZ).subtract(start).normalize();
            }
        }
        return p.getLookVec();
    }

    private static Vec3d right(EntityPlayerMP p) {
        double yaw = Math.toRadians(p.rotationYaw);
        return new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
    }

    private static void fireRepulsor(EntityPlayerMP p, SuitData d) {
        Vec3d start = p.getPositionEyes(1F);
        Vec3d dir = aim(p, d, start);
        Vec3d hand = start.add(right(p).scale(0.35)).addVector(0, -0.3, 0).add(dir.scale(0.5));
        RayUtil.Hit h = RayUtil.trace(p.world, p, start, dir, 48, 0.3);
        if (h.entity != null) {
            h.entity.attackEntityFrom(DamageSource.causePlayerDamage(p), (float) (d.suit.repulsorDamage * ModConfig.damageMultiplier));
            h.entity.addVelocity(dir.x * 0.5, 0.2, dir.z * 0.5);
            h.entity.velocityChanged = true;
        }
        ((WorldServer) p.world).spawnParticle(EnumParticleTypes.CRIT_MAGIC, h.pos.x, h.pos.y, h.pos.z, 10, 0.2, 0.2, 0.2, 0.08);
        ((WorldServer) p.world).spawnParticle(EnumParticleTypes.FIREWORKS_SPARK, h.pos.x, h.pos.y, h.pos.z, 4, 0.1, 0.1, 0.1, 0.05);
        effect(p, new PacketEffect(PacketEffect.BEAM).id(0).color(d.suit.hudColor)
                .pos(hand.x, hand.y, hand.z).vec(h.pos.x, h.pos.y, h.pos.z), 80);
        sound(p, SoundEvents.ENTITY_FIREWORK_LARGE_BLAST, 0.8F, 1.7F);
        d.energy -= REP_COST;
        d.repCooldown = 6;
    }

    private static void fireUnibeam(EntityPlayerMP p, SuitData d) {
        Vec3d start = p.getPositionEyes(1F).addVector(0, -0.5, 0);
        Vec3d dir = aim(p, d, start);
        Vec3d origin = start.add(dir.scale(0.4));
        double range = 80;
        Vec3d end = origin.add(dir.scale(range));
        net.minecraft.util.math.RayTraceResult block = p.world.rayTraceBlocks(origin, end, false, true, false);
        if (block != null && block.hitVec != null) end = block.hitVec;
        AxisAlignedBB box = new AxisAlignedBB(origin, end).grow(2);
        List<EntityLivingBase> list = p.world.getEntitiesWithinAABB(EntityLivingBase.class, box);
        for (EntityLivingBase e : list) {
            if (e == p || !e.isEntityAlive()) continue;
            if (e.getEntityBoundingBox().grow(0.9).calculateIntercept(origin, end) != null) {
                e.attackEntityFrom(DamageSource.causePlayerDamage(p), (float) (d.suit.unibeamDamage * ModConfig.damageMultiplier));
                e.setFire(4);
                e.addVelocity(dir.x * 1.2, 0.5, dir.z * 1.2);
                e.velocityChanged = true;
            }
        }
        p.world.createExplosion(p, end.x, end.y, end.z, 3.0F, ModConfig.blockDamage);
        d.energy -= BEAM_COST;
        sound(p, SoundEvents.ENTITY_GENERIC_EXPLODE, 1.5F, 0.6F);
        sound(p, SoundEvents.ENTITY_LIGHTNING_THUNDER, 1.2F, 1.5F);
        effect(p, new PacketEffect(PacketEffect.BEAM).id(1).color(0xFFFFFF)
                .pos(origin.x, origin.y, origin.z).vec(end.x, end.y, end.z), 128);
        NetworkHandler.NET.sendTo(new PacketEffect(PacketEffect.SHAKE).vec(1.6, 0, 0)
                .pos(-dir.x * 0.8, -dir.y * 0.4, -dir.z * 0.8), p);
    }

    private static void launchMissile(EntityPlayerMP p, SuitData d, int index) {
        Vec3d start = p.getPositionEyes(1F);
        Vec3d dir = aim(p, d, start);
        double side = (index % 2 == 0) ? 0.5 : -0.5;
        Vec3d pos = start.add(right(p).scale(side)).addVector(0, 0.3, 0);
        Vec3d spread = dir.addVector((p.getRNG().nextDouble() - 0.5) * 0.3, (p.getRNG().nextDouble() - 0.2) * 0.3,
                (p.getRNG().nextDouble() - 0.5) * 0.3);
        float power = d.suit == SuitType.MARK1 ? 1.6F : 2.2F;
        EntityMissile m = new EntityMissile(p.world, p, d.lockOn ? d.lockTarget : -1, spread, pos, power);
        p.world.spawnEntity(m);
        sound(p, SoundEvents.ENTITY_FIREWORK_LAUNCH, 1F, 0.9F);
    }

    private static void flame(EntityPlayerMP p, SuitData d) {
        Vec3d start = p.getPositionEyes(1F).addVector(0, -0.3, 0);
        Vec3d dir = p.getLookVec();
        WorldServer w = (WorldServer) p.world;
        for (int i = 1; i <= 6; i++) {
            Vec3d q = start.add(dir.scale(i));
            w.spawnParticle(EnumParticleTypes.FLAME, q.x, q.y, q.z, 3, 0.15 * i * 0.3, 0.15 * i * 0.3, 0.15 * i * 0.3, 0.02);
        }
        if (p.ticksExisted % 8 == 0) sound(p, SoundEvents.ITEM_FLINTANDSTEEL_USE, 0.7F, 0.6F);
        if (p.ticksExisted % 4 != 0) return;
        List<EntityLivingBase> list = w.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(7));
        for (EntityLivingBase e : list) {
            if (e == p || !e.isEntityAlive()) continue;
            Vec3d to = new Vec3d(e.posX, e.posY + e.height * 0.5, e.posZ).subtract(start);
            double dist = to.lengthVector();
            if (dist < 7 && to.normalize().dotProduct(dir) > 0.85) {
                e.setFire(6);
                e.attackEntityFrom(DamageSource.causePlayerDamage(p), (float) (2F * ModConfig.damageMultiplier));
            }
        }
    }

    private static void tickLock(EntityPlayerMP p, SuitData d) {
        if (!d.lockOn || !d.suit.has(Feature.LOCKON)) {
            d.lockTarget = -1;
            return;
        }
        if (p.ticksExisted % 5 != 0) return;
        Entity cur = d.lockTarget >= 0 ? p.world.getEntityByID(d.lockTarget) : null;
        if (cur instanceof EntityLivingBase && cur.isEntityAlive() && cur.getDistanceSq(p) < 48 * 48
                && p.canEntityBeSeen(cur)) return;
        d.lockTarget = -1;
        Vec3d eye = p.getPositionEyes(1F);
        Vec3d look = p.getLookVec();
        double best = -10;
        EntityLivingBase bestE = null;
        for (EntityLivingBase e : p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(40))) {
            if (e == p || !e.isEntityAlive() || !(e instanceof IMob)) continue;
            Vec3d to = new Vec3d(e.posX, e.posY + e.height * 0.5, e.posZ).subtract(eye);
            double dist = to.lengthVector();
            double dot = to.normalize().dotProduct(look);
            if (dot > 0.6 && p.canEntityBeSeen(e)) {
                double score = dot - dist * 0.005;
                if (score > best) {
                    best = score;
                    bestE = e;
                }
            }
        }
        d.lockTarget = bestE == null ? -1 : bestE.getEntityId();
    }

    // ------------------------------------------------------------------ takim giyme sinematigi
    private static boolean hasAll(EntityPlayerMP p, SuitType s) {
        for (EntityEquipmentSlot sl : SuitType.ARMOR_SLOTS) {
            Item it = ModItems.piece(s, sl);
            if (p.getItemStackFromSlot(sl).getItem() == it) continue;
            if (findInMain(p, it) < 0) return false;
        }
        return true;
    }

    private static int findInMain(EntityPlayerMP p, Item it) {
        for (int i = 0; i < p.inventory.mainInventory.size(); i++) {
            if (p.inventory.mainInventory.get(i).getItem() == it) return i;
        }
        return -1;
    }

    private static void trySuitUp(EntityPlayerMP p, SuitData d) {
        if (d.suitUpTimer > 0) return;
        SuitType found = null;
        for (int i = SuitType.VALUES.length - 1; i >= 0 && found == null; i--) {
            SuitType s = SuitType.VALUES[i];
            if (d.suit == s) continue;
            if (hasAll(p, s)) found = s;
        }
        if (found == null) {
            jarvis(p, "ironmanmod.jarvis.no_suit");
            return;
        }
        d.suitUpType = found;
        d.suitUpTimer = SUITUP_TICKS;
        sound(p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2F, 0.6F);
        effect(p, new PacketEffect(PacketEffect.SUITUP).id(p.getEntityId()).pos(p.posX, p.posY, p.posZ).vec(SUITUP_TICKS, 0, 0), 64);
        jarvis(p, "ironmanmod.jarvis.suitup");
    }

    private static void tickSuitUp(EntityPlayerMP p, SuitData d) {
        if (d.suitUpTimer <= 0) return;
        d.suitUpTimer--;
        if (d.suitUpTimer % 15 == 0 && d.suitUpTimer > 0) sound(p, SoundEvents.BLOCK_ANVIL_PLACE, 0.5F, 1.8F);
        if (d.suitUpTimer == 0) {
            SuitType t = d.suitUpType;
            if (t != null && hasAll(p, t)) {
                for (EntityEquipmentSlot sl : SuitType.ARMOR_SLOTS) {
                    Item it = ModItems.piece(t, sl);
                    if (p.getItemStackFromSlot(sl).getItem() == it) continue;
                    int idx = findInMain(p, it);
                    if (idx < 0) continue;
                    ItemStack ns = p.inventory.mainInventory.get(idx);
                    ItemStack old = p.getItemStackFromSlot(sl);
                    p.inventory.mainInventory.set(idx, old);
                    p.setItemStackToSlot(sl, ns);
                }
                p.inventoryContainer.detectAndSendChanges();
                changeSuit(p, d, t);
                d.faceClosed = false;
                d.faceTimer = 30;
                sound(p, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 1.2F, 0.7F);
                sound(p, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.4F, 1.8F);
                sendState(p, d);
            } else {
                jarvis(p, "ironmanmod.jarvis.no_suit");
            }
        }
    }

    // ------------------------------------------------------------------ olaylar
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        SuitData d = SuitManager.peek(p.getUniqueID());
        if (d == null || d.suit == null) return;
        if (d.suit.has(Feature.SHIELD) && d.energy > 200 && !e.getSource().canHarmInCreative()) {
            float absorb = e.getAmount() * 0.4F;
            e.setAmount(e.getAmount() - absorb);
            d.energy -= absorb * 60;
            ((WorldServer) p.world).spawnParticle(EnumParticleTypes.CRIT_MAGIC, p.posX, p.posY + 1, p.posZ, 12, 0.4, 0.6, 0.4, 0.1);
        }
        NetworkHandler.NET.sendTo(new PacketEffect(PacketEffect.SHAKE).vec(0.5, 0, 0), p);
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        SuitData d = SuitManager.peek(p.getUniqueID());
        if (d == null || d.suit == null) return;
        float dist = e.getDistance();
        e.setDamageMultiplier(0.25F);
        if (d.suit.has(Feature.SHOCKWAVE) && dist >= 6F && d.energy >= 100) {
            e.setDamageMultiplier(0F);
            landing(p, d, dist);
        }
    }

    private static void landing(EntityPlayerMP p, SuitData d, float dist) {
        double r = Math.min(9, 2.5 + dist * 0.25);
        float dmg = (float) Math.min(24, dist * 0.9);
        List<EntityLivingBase> list = p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r, 2, r));
        for (EntityLivingBase e : list) {
            if (e == p) continue;
            double dd = e.getDistance(p);
            if (dd > r) continue;
            e.attackEntityFrom(DamageSource.causePlayerDamage(p), (float) (dmg * (1 - dd / r * 0.7) * ModConfig.damageMultiplier));
            double nx = e.posX - p.posX, nz = e.posZ - p.posZ;
            double l = Math.max(0.1, Math.sqrt(nx * nx + nz * nz));
            e.addVelocity(nx / l * 0.9, 0.5, nz / l * 0.9);
            e.velocityChanged = true;
        }
        d.energy -= 100;
        sound(p, SoundEvents.ENTITY_GENERIC_EXPLODE, 1.5F, 0.5F);
        effect(p, new PacketEffect(PacketEffect.LANDING).pos(p.posX, p.posY, p.posZ).vec(r, 0, 0), 64);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        SuitData d = SuitManager.peek(p.getUniqueID());
        if (d != null && d.suit != null) {
            setFlightAbility(p, false);
            d.reset();
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) {
            setFlightAbility((EntityPlayerMP) e.player, false);
            SuitManager.remove(e.player.getUniqueID());
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        SuitManager.remove(e.player.getUniqueID());
    }

    // ------------------------------------------------------------------ yardimcilar
    private static void sound(EntityPlayerMP p, SoundEvent s, float vol, float pitch) {
        p.world.playSound(null, p.posX, p.posY, p.posZ, s, SoundCategory.PLAYERS, vol, pitch);
    }

    private static void effect(EntityPlayerMP p, PacketEffect m, double range) {
        NetworkHandler.NET.sendToAllAround(m, new NetworkRegistry.TargetPoint(p.dimension, p.posX, p.posY, p.posZ, range));
    }

    private static void jarvis(EntityPlayerMP p, String key) {
        NetworkHandler.NET.sendTo(PacketEffect.jarvis(key), p);
    }
}
