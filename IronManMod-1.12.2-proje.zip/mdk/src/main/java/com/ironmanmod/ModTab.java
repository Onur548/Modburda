package com.ironmanmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;

public class ModTab {
    public static final CreativeTabs TAB = new CreativeTabs("ironmanmod") {
        @Override
        public ItemStack getTabIconItem() {
            return new ItemStack(ModItems.piece(SuitType.MARK85, EntityEquipmentSlot.HEAD));
        }
    };
}
