package com.ironmanmod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

public class RayUtil {
    public static class Hit {
        public Vec3d pos;
        public EntityLivingBase entity;
    }

    /** Bloklara ve canlilara karsi isin izleme. */
    public static Hit trace(World world, EntityPlayer p, Vec3d start, Vec3d dir, double range, double grow) {
        Vec3d end = start.add(dir.scale(range));
        Hit h = new Hit();
        RayTraceResult block = world.rayTraceBlocks(start, end, false, true, false);
        double max = range;
        h.pos = end;
        if (block != null && block.hitVec != null) {
            max = block.hitVec.distanceTo(start);
            h.pos = block.hitVec;
        }
        double best = max;
        AxisAlignedBB box = new AxisAlignedBB(start, end).grow(1.5);
        List<EntityLivingBase> list = world.getEntitiesWithinAABB(EntityLivingBase.class, box);
        for (EntityLivingBase e : list) {
            if (e == p || !e.isEntityAlive()) continue;
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(grow);
            RayTraceResult r = bb.calculateIntercept(start, end);
            if (bb.contains(start)) {
                h.entity = e;
                h.pos = start;
                best = 0;
            } else if (r != null) {
                double d = start.distanceTo(r.hitVec);
                if (d < best) {
                    best = d;
                    h.entity = e;
                    h.pos = r.hitVec;
                }
            }
        }
        return h;
    }
}
