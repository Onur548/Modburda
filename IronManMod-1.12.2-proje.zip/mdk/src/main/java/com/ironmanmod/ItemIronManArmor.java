package com.ironmanmod;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;

public class ItemIronManArmor extends ItemArmor {
    private final SuitType suit;

    public ItemIronManArmor(SuitType suit, EntityEquipmentSlot slot) {
        super(suit.material(), 0, slot);
        this.suit = suit;
        String n = suit.id + "_" + slotName(slot);
        setRegistryName(IronManMod.MODID, n);
        setUnlocalizedName(IronManMod.MODID + "." + n);
        setCreativeTab(ModTab.TAB);
    }

    public static String slotName(EntityEquipmentSlot s) {
        switch (s) {
            case HEAD: return "helmet";
            case CHEST: return "chestplate";
            case LEGS: return "leggings";
            default: return "boots";
        }
    }

    public SuitType getSuit() {
        return suit;
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EntityEquipmentSlot slot, String type) {
        return IronManMod.MODID + ":textures/models/armor/" + suit.id + "_layer_" + (slot == EntityEquipmentSlot.LEGS ? 2 : 1) + ".png";
    }

    @Override
    @SideOnly(Side.CLIENT)
    public ModelBiped getArmorModel(EntityLivingBase entity, ItemStack stack, EntityEquipmentSlot slot, ModelBiped _default) {
        return com.ironmanmod.client.ModelIronMan.get(slot);
    }

    @Override
    public boolean getIsRepairable(ItemStack a, ItemStack b) {
        return false;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add("\u00a76" + suit.displayName);
        if (armorType == EntityEquipmentSlot.CHEST) {
            tooltip.add("\u00a7b" + I18n.format("ironmanmod.tooltip.energy") + ": " + getEnergy(stack) + " / " + suit.maxEnergy);
        }
        for (Feature f : Feature.values()) {
            if (suit.has(f)) tooltip.add("\u00a77- " + I18n.format("ironmanmod.feature." + f.name().toLowerCase()));
        }
    }

    public static int getEnergy(ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof ItemIronManArmor)) return 0;
        SuitType st = ((ItemIronManArmor) s.getItem()).getSuit();
        NBTTagCompound t = s.getTagCompound();
        if (t == null || !t.hasKey("Energy")) return st.maxEnergy;
        return t.getInteger("Energy");
    }

    public static void setEnergy(ItemStack s, int e) {
        if (s.isEmpty()) return;
        NBTTagCompound t = s.getTagCompound();
        if (t == null) {
            t = new NBTTagCompound();
            s.setTagCompound(t);
        }
        t.setInteger("Energy", e);
    }
}
