package com.ironmanmod.client;

import com.ironmanmod.SuitData;
import com.ironmanmod.SuitType;
import com.ironmanmod.net.PacketState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.resources.I18n;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ClientSuitManager {
    private static final Map<UUID, SuitData> MAP = new HashMap<>();
    public static int hudBoot;
    public static int hudMode; // 0 tam, 1 minimal, 2 kapali
    public static float damageFlash;
    public static final List<Line> LOG = new ArrayList<>();
    public static final List<SuitUpFx> SUITUP = new ArrayList<>();

    public static class Line {
        public String text;
        public int age;
    }

    public static class SuitUpFx {
        public int entityId, left, total;
    }

    public static SuitData get(UUID id) {
        return MAP.get(id);
    }

    public static SuitData self() {
        EntityPlayerSP p = Minecraft.getMinecraft().player;
        return p == null ? null : MAP.get(p.getUniqueID());
    }

    public static boolean isSelf(UUID id) {
        EntityPlayerSP p = Minecraft.getMinecraft().player;
        return p != null && p.getUniqueID().equals(id);
    }

    public static void jarvis(String text) {
        if (!LOG.isEmpty()) {
            Line last = LOG.get(LOG.size() - 1);
            if (last.text.equals(text) && last.age < 60) return;
        }
        Line l = new Line();
        l.text = text;
        LOG.add(l);
        while (LOG.size() > 6) LOG.remove(0);
    }

    public static void update(PacketState m) {
        if (m.suit < 0) {
            SuitData old = MAP.remove(m.id);
            if (old != null && isSelf(m.id)) jarvis(I18n.format("ironmanmod.jarvis.offline"));
            return;
        }
        SuitData d = MAP.get(m.id);
        boolean fresh = d == null;
        if (fresh) {
            d = new SuitData();
            MAP.put(m.id, d);
            d.faceOpen = d.facePrev = (m.bits & 1) != 0 ? 0F : 1F;
        }
        boolean wasClosed = d.faceClosed;
        d.suit = SuitType.VALUES[m.suit];
        d.setBits(m.bits);
        d.energy = m.energy;
        d.maxEnergy = m.maxEnergy;
        d.lockTarget = m.lockTarget;
        d.unibeamCharge = m.charge;
        d.beamCooldown = m.beamCd;
        d.missileCooldown = m.missileCd;
        if (isSelf(m.id) && (fresh || (!wasClosed && d.faceClosed))) hudBoot = 0;
    }

    public static void tick() {
        hudBoot++;
        if (damageFlash > 0) damageFlash -= 0.06F;
        for (int i = LOG.size() - 1; i >= 0; i--) {
            Line l = LOG.get(i);
            if (++l.age > 140) LOG.remove(i);
        }
    }

    public static void clear() {
        MAP.clear();
        LOG.clear();
        SUITUP.clear();
    }
}
