package com.ironmanmod.client;

import com.ironmanmod.SuitData;
import com.ironmanmod.net.PacketEffect;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClientEffects {
    private static class Beam {
        Vec3d a, b;
        int ttl, style, color;
    }

    private static final List<Beam> BEAMS = new ArrayList<>();

    public static void handle(PacketEffect m) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null) return;
        World w = mc.world;
        switch (m.type) {
            case PacketEffect.JARVIS:
                ClientSuitManager.jarvis(I18n.format(m.s));
                break;
            case PacketEffect.BEAM: {
                Beam b = new Beam();
                b.a = new Vec3d(m.x, m.y, m.z);
                b.b = new Vec3d(m.a, m.b, m.c);
                b.style = m.id;
                b.color = m.color;
                b.ttl = m.id == 1 ? 8 : 2;
                BEAMS.add(b);
                if (m.id == 1) {
                    FX.burst(w, b.b, 40, 0xFFFFFF, 0.5, 1.2F, 14);
                    double dist = mc.player.getDistance(m.x, m.y, m.z);
                    if (dist < 40) Cinematic.shake(1.0 - dist / 40.0);
                }
                break;
            }
            case PacketEffect.LANDING: {
                Vec3d c = new Vec3d(m.x, m.y + 0.1, m.z);
                FX.ring(w, c, new Vec3d(0, 1, 0), 0.8, 36, 0xDDEEFF, 0.55, 0.9F, 16);
                FX.ring(w, c, new Vec3d(0, 1, 0), 0.4, 24, 0x7FE0FF, 0.35, 0.7F, 14);
                BlockPos below = new BlockPos(m.x, m.y - 0.5, m.z);
                IBlockState st = w.getBlockState(below);
                int id = Block.getStateId(st.getBlock() == Blocks.AIR ? Blocks.STONE.getDefaultState() : st);
                for (int i = 0; i < 50; i++) {
                    double ang = Math.random() * Math.PI * 2, sp = 0.2 + Math.random() * 0.6;
                    w.spawnParticle(EnumParticleTypes.BLOCK_DUST, m.x, m.y + 0.2, m.z,
                            Math.cos(ang) * sp, 0.3 + Math.random() * 0.5, Math.sin(ang) * sp, id);
                }
                w.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, m.x, m.y + 0.5, m.z, 0, 0, 0);
                double dist = mc.player.getDistance(m.x, m.y, m.z);
                if (dist < 32) Cinematic.shake(1.8 * (1 - dist / 32));
                break;
            }
            case PacketEffect.SUITUP: {
                ClientSuitManager.SuitUpFx fx = new ClientSuitManager.SuitUpFx();
                fx.entityId = m.id;
                fx.total = fx.left = (int) m.a;
                ClientSuitManager.SUITUP.add(fx);
                if (m.id == mc.player.getEntityId()) Cinematic.startSuitUp((int) m.a);
                break;
            }
            case PacketEffect.FLIGHT_START: {
                Vec3d c = new Vec3d(m.x, m.y + 0.1, m.z);
                FX.ring(w, c, new Vec3d(0, 1, 0), 0.5, 30, 0x9FEFFF, 0.4, 0.8F, 14);
                FX.burst(w, c, 30, 0xFFFFFF, 0.3, 0.7F, 12);
                SuitData d = ClientSuitManager.self();
                if (m.id == mc.player.getEntityId()) Cinematic.shake(0.9);
                break;
            }
            case PacketEffect.SHAKE: {
                Cinematic.shake(m.a);
                SuitData d = ClientSuitManager.self();
                if (d != null && d.flying) {
                    d.vx += m.x;
                    d.vy += m.y;
                    d.vz += m.z;
                } else if (m.x != 0 || m.z != 0) {
                    mc.player.motionX += m.x;
                    mc.player.motionY += m.y;
                    mc.player.motionZ += m.z;
                }
                break;
            }
            default:
                break;
        }
    }

    public static void tick(Minecraft mc) {
        World w = mc.world;
        // isinlar
        Iterator<Beam> it = BEAMS.iterator();
        while (it.hasNext()) {
            Beam b = it.next();
            Vec3d d = b.b.subtract(b.a);
            double len = d.lengthVector();
            if (len > 0.01) {
                Vec3d dir = d.scale(1 / len);
                double step = b.style == 1 ? 0.45 : 0.8;
                float size = b.style == 1 ? 0.9F : 0.3F;
                for (double t = 0; t < len; t += step) {
                    Vec3d p = b.a.add(dir.scale(t));
                    double j = b.style == 1 ? 0.25 : 0.03;
                    FX.glow(w, p.x + (FX.R.nextDouble() - 0.5) * j, p.y + (FX.R.nextDouble() - 0.5) * j,
                            p.z + (FX.R.nextDouble() - 0.5) * j, 0, 0, 0,
                            b.style == 1 ? (FX.R.nextInt(3) == 0 ? 0x9FEFFF : 0xFFFFFF) : b.color, size, b.style == 1 ? 6 : 3);
                }
            }
            if (--b.ttl <= 0) it.remove();
        }
        // takim giyme montaj efekti
        Iterator<ClientSuitManager.SuitUpFx> sit = ClientSuitManager.SUITUP.iterator();
        while (sit.hasNext()) {
            ClientSuitManager.SuitUpFx fx = sit.next();
            Entity e = w.getEntityByID(fx.entityId);
            fx.left--;
            if (e == null) {
                if (fx.left <= 0) sit.remove();
                continue;
            }
            float prog = 1F - fx.left / (float) Math.max(1, fx.total);
            int phase = Math.min(4, (int) (prog * 5));
            double[] ys = {0.15, 0.7, 1.2, 1.65};
            if (phase < 4) {
                for (int i = 0; i < 7; i++) {
                    double ox = FX.R.nextGaussian(), oy = FX.R.nextGaussian() * 0.6, oz = FX.R.nextGaussian();
                    double l = Math.max(0.1, Math.sqrt(ox * ox + oy * oy + oz * oz));
                    double r = 2.5;
                    double sx = e.posX + ox / l * r, sy = e.posY + ys[phase] + oy / l * r, sz = e.posZ + oz / l * r;
                    double life = 7;
                    FX.glow(w, sx, sy, sz, (e.posX - sx) / life, (e.posY + ys[phase] - sy) / life, (e.posZ - sz) / life,
                            i % 2 == 0 ? 0xFFC83C : 0xCC2222, 0.6F, 8);
                }
                if (fx.left % 6 == 0) {
                    FX.ring(w, new Vec3d(e.posX, e.posY + ys[phase], e.posZ), new Vec3d(0, 1, 0), 0.9, 16, 0x9FEFFF, -0.1, 0.5F, 8);
                }
            }
            if (fx.left <= 0) {
                FX.burst(w, new Vec3d(e.posX, e.posY + 1, e.posZ), 60, 0xFFFFFF, 0.45, 1F, 16);
                FX.ring(w, new Vec3d(e.posX, e.posY + 0.1, e.posZ), new Vec3d(0, 1, 0), 0.6, 36, 0x9FEFFF, 0.5, 0.9F, 16);
                sit.remove();
            }
        }
    }

    // oyuncu basina gorsel efektler (ucus, repulsor, sarj, ses duvari)
    public static void playerFx(Minecraft mc, EntityPlayer p, SuitData d) {
        World w = mc.world;
        double yaw = Math.toRadians(p.renderYawOffset);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        int rgb = d.suit.hudColor;

        if (d.flying) {
            double sinT = Math.sin(Math.toRadians(d.lean)), cosT = Math.cos(Math.toRadians(d.lean));
            double dx = p.posX - p.prevPosX, dy = p.posY - p.prevPosY, dz = p.posZ - p.prevPosZ;
            int n = 1 + (int) (d.speed * 2) + (d.boosting ? 3 : 0);
            for (int side = -1; side <= 1; side += 2) {
                double bx = p.posX - 0.9 * sinT * fx + rx * 0.15 * side;
                double by = p.posY + 0.9 - 0.9 * cosT + 0.1;
                double bz = p.posZ - 0.9 * sinT * fz + rz * 0.15 * side;
                for (int i = 0; i < n; i++) {
                    double mx = -dx * 0.6 + (FX.R.nextDouble() - 0.5) * 0.05;
                    double my = -dy * 0.6 - 0.12 + (FX.R.nextDouble() - 0.5) * 0.05;
                    double mz = -dz * 0.6 + (FX.R.nextDouble() - 0.5) * 0.05;
                    FX.glow(w, bx, by, bz, mx, my, mz, d.boosting ? 0xFFFFFF : rgb, d.boosting ? 0.7F : 0.45F, 6);
                    if (FX.R.nextInt(2) == 0) w.spawnParticle(EnumParticleTypes.FLAME, bx, by, bz, mx, my, mz);
                }
                if (FX.R.nextInt(6) == 0) w.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, bx, by, bz, -dx * 0.3, -0.05, -dz * 0.3);
            }
            // ses duvari konisi
            if (d.speed > 2.4 && p.ticksExisted % 3 == 0) {
                Vec3d vel = new Vec3d(dx, dy, dz);
                Vec3d c = new Vec3d(p.posX, p.posY + 0.9, p.posZ).add(vel.normalize().scale(1.2));
                FX.ring(w, c, vel, 1.4, 14, 0xFFFFFF, -0.05, 0.6F, 8);
                if (p == mc.player) Cinematic.shake(0.15);
            }
        }
        if (d.repulsor) {
            double hx = p.posX + rx * 0.4 + fx * 0.35, hz = p.posZ + rz * 0.4 + fz * 0.35;
            double hy = p.posY + p.getEyeHeight() - 0.35;
            for (int i = 0; i < 2; i++) FX.glow(w, hx, hy, hz, 0, 0, 0, 0xFFFFFF, 0.5F, 3);
            FX.glow(w, hx, hy, hz, (FX.R.nextDouble() - 0.5) * 0.05, 0.02, (FX.R.nextDouble() - 0.5) * 0.05, rgb, 0.8F, 4);
        }
        if (d.unibeamCharge > 0) {
            double cx = p.posX + fx * 0.3, cy = p.posY + 1.2, cz = p.posZ + fz * 0.3;
            double r = 2.0 - d.unibeamCharge * 0.04;
            for (int i = 0; i < 4; i++) {
                double ox = FX.R.nextGaussian(), oy = FX.R.nextGaussian(), oz = FX.R.nextGaussian();
                double l = Math.max(0.1, Math.sqrt(ox * ox + oy * oy + oz * oz));
                double sx = cx + ox / l * r, sy = cy + oy / l * r, sz = cz + oz / l * r;
                FX.glow(w, sx, sy, sz, (cx - sx) / 5, (cy - sy) / 5, (cz - sz) / 5, 0xBFF4FF, 0.5F, 5);
            }
            FX.glow(w, cx, cy, cz, 0, 0, 0, 0xFFFFFF, 0.5F + d.unibeamCharge * 0.07F, 2);
        }
    }
}
