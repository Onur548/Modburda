package com.ironmanmod.client;

import com.ironmanmod.CommonProxy;
import com.ironmanmod.EntityMissile;
import com.ironmanmod.net.PacketEffect;
import com.ironmanmod.net.PacketState;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityMissile.class, RenderMissile::new);
    }

    @Override
    public void init() {
        KeyBindings.register();
        MinecraftForge.EVENT_BUS.register(new ClientHandler());
        MinecraftForge.EVENT_BUS.register(new Cinematic());
        MinecraftForge.EVENT_BUS.register(new HudRenderer());
    }

    @Override
    public void handleState(final PacketState m) {
        Minecraft.getMinecraft().addScheduledTask(() -> ClientSuitManager.update(m));
    }

    @Override
    public void handleEffect(final PacketEffect m) {
        Minecraft.getMinecraft().addScheduledTask(() -> ClientEffects.handle(m));
    }
}
