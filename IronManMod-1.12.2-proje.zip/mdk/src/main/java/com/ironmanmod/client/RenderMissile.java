package com.ironmanmod.client;

import com.ironmanmod.EntityMissile;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Fuze gorunumu tamamen partikullerle yapilir; model cizilmez. */
public class RenderMissile extends Render<EntityMissile> {
    public RenderMissile(RenderManager m) {
        super(m);
    }

    @Override
    public void doRender(EntityMissile e, double x, double y, double z, float yaw, float pt) {}

    @Override
    protected ResourceLocation getEntityTexture(EntityMissile e) {
        return null;
    }
}
