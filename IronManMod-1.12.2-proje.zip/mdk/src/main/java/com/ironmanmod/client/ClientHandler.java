package com.ironmanmod.client;

import com.ironmanmod.Feature;
import com.ironmanmod.SuitData;
import com.ironmanmod.net.NetworkHandler;
import com.ironmanmod.net.PacketKey;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

public class ClientHandler {
    private final boolean[] held = new boolean[PacketKey.Action.values().length];

    private void toggle(KeyBinding k, PacketKey.Action a) {
        while (k.isPressed()) NetworkHandler.NET.sendToServer(new PacketKey(a, true));
    }

    private void hold(KeyBinding k, PacketKey.Action a, boolean allowed) {
        boolean down = allowed && k.isKeyDown();
        if (down != held[a.ordinal()]) {
            held[a.ordinal()] = down;
            NetworkHandler.NET.sendToServer(new PacketKey(a, down));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;
        boolean noGui = mc.currentScreen == null;

        if (noGui) {
            toggle(KeyBindings.FLIGHT, PacketKey.Action.FLIGHT);
            toggle(KeyBindings.FACE, PacketKey.Action.FACE);
            toggle(KeyBindings.MISSILES, PacketKey.Action.MISSILES);
            toggle(KeyBindings.HOVER, PacketKey.Action.HOVER);
            toggle(KeyBindings.SUITUP, PacketKey.Action.SUITUP);
            toggle(KeyBindings.VISION, PacketKey.Action.VISION);
            toggle(KeyBindings.LOCKON, PacketKey.Action.LOCKON);
            while (KeyBindings.CINEMA.isPressed()) Cinematic.toggleCinema();
            while (KeyBindings.HUD.isPressed()) {
                ClientSuitManager.hudMode = (ClientSuitManager.hudMode + 1) % 3;
                ClientSuitManager.jarvis(net.minecraft.client.resources.I18n.format("ironmanmod.hud.mode" + ClientSuitManager.hudMode));
            }
        }
        hold(KeyBindings.REPULSOR, PacketKey.Action.REPULSOR, noGui);
        hold(KeyBindings.UNIBEAM, PacketKey.Action.UNIBEAM, noGui);
        hold(KeyBindings.BOOST, PacketKey.Action.BOOST, noGui);
        hold(KeyBindings.FLAME, PacketKey.Action.FLAME, noGui);

        EntityPlayerSP me = mc.player;
        for (EntityPlayer pl : mc.world.playerEntities) {
            SuitData d = ClientSuitManager.get(pl.getUniqueID());
            if (d == null || d.suit == null) continue;
            visuals(mc, pl, d);
        }
        SuitData sd = ClientSuitManager.self();
        if (sd != null && sd.suit != null) flight(mc, me, sd);
        ClientEffects.tick(mc);
        Cinematic.tick(mc, sd);
        ClientSuitManager.tick();
    }

    private void visuals(Minecraft mc, EntityPlayer pl, SuitData d) {
        d.facePrev = d.faceOpen;
        float tgt = d.faceClosed ? 0F : 1F;
        float diff = tgt - d.faceOpen;
        d.faceOpen += Math.max(-0.12F, Math.min(0.12F, diff));
        double dx = pl.posX - pl.prevPosX, dy = pl.posY - pl.prevPosY, dz = pl.posZ - pl.prevPosZ;
        d.speed = Math.sqrt(dx * dx + dy * dy + dz * dz);
        d.leanPrev = d.lean;
        float lt = d.flying ? (float) Math.min(80.0, Math.sqrt(dx * dx + dz * dz) * 70.0) : 0F;
        d.lean += (lt - d.lean) * 0.2F;
        ClientEffects.playerFx(mc, pl, d);
    }

    private void flight(Minecraft mc, EntityPlayerSP p, SuitData d) {
        boolean active = d.flying && d.suit.has(Feature.FLIGHT) && d.energy > 0;
        if (!active) {
            d.wasFlying = false;
            return;
        }
        if (!d.wasFlying) {
            d.wasFlying = true;
            d.vx = p.motionX;
            d.vy = Math.max(p.motionY, 0.55);
            d.vz = p.motionZ;
        }
        GameSettings gs = mc.gameSettings;
        boolean in = mc.currentScreen == null;
        Vec3d look = p.getLookVec();
        double yaw = Math.toRadians(p.rotationYaw);
        double ix = 0, iy = 0, iz = 0;
        boolean thrust = false;
        if (in && gs.keyBindForward.isKeyDown()) { ix += look.x; iy += look.y; iz += look.z; thrust = true; }
        if (in && gs.keyBindBack.isKeyDown()) { ix -= look.x * 0.6; iy -= look.y * 0.6; iz -= look.z * 0.6; thrust = true; }
        if (in && gs.keyBindLeft.isKeyDown()) { ix += Math.cos(yaw) * 0.6; iz += Math.sin(yaw) * 0.6; thrust = true; }
        if (in && gs.keyBindRight.isKeyDown()) { ix -= Math.cos(yaw) * 0.6; iz -= Math.sin(yaw) * 0.6; thrust = true; }
        if (in && gs.keyBindJump.isKeyDown()) { iy += 0.8; thrust = true; }
        if (in && gs.keyBindSneak.isKeyDown()) { iy -= 0.8; thrust = true; }
        if (d.boosting) { ix += look.x; iy += look.y; iz += look.z; thrust = true; }

        double max = d.suit.flightSpeed * (d.boosting ? 2.4 : 1.0) * (d.hover ? 0.5 : 1.0);
        double acc = (d.hover ? 0.2 : 0.07) * (d.boosting ? 2.2 : 1.0);
        if (thrust) {
            double len = Math.sqrt(ix * ix + iy * iy + iz * iz);
            if (len > 0.001) {
                d.vx += ix / len * acc;
                d.vy += iy / len * acc;
                d.vz += iz / len * acc;
            }
            double sp = Math.sqrt(d.vx * d.vx + d.vy * d.vy + d.vz * d.vz);
            if (sp > max) {
                double k = max / sp;
                d.vx *= k;
                d.vy *= k;
                d.vz *= k;
            }
        } else {
            double f = d.hover ? 0.55 : 0.96;
            d.vx *= f;
            d.vy *= f;
            d.vz *= f;
        }
        if (p.collidedHorizontally) { d.vx *= 0.3; d.vz *= 0.3; }
        if (p.collidedVertically) d.vy = d.vy < 0 && p.onGround ? 0 : d.vy * 0.2;

        p.motionX = d.vx;
        p.motionY = d.vy;
        p.motionZ = d.vz;
        p.fallDistance = 0F;
        p.capabilities.isFlying = false;
    }

    // ---- ucus egimi (oyuncu govdesi ileri yatar)
    @SubscribeEvent
    public void onRenderPre(RenderPlayerEvent.Pre e) {
        SuitData d = ClientSuitManager.get(e.getEntityPlayer().getUniqueID());
        if (d == null || d.suit == null || !d.flying) return;
        float lean = d.lean((float) e.getPartialRenderTick());
        if (lean < 3F) return;
        EntityPlayer p = e.getEntityPlayer();
        float pt = e.getPartialRenderTick();
        float yawOff = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        double yaw = Math.toRadians(yawOff);
        GlStateManager.pushMatrix();
        GlStateManager.translate(e.getX(), e.getY() + 0.9, e.getZ());
        GlStateManager.rotate(lean, (float) Math.cos(yaw), 0F, (float) Math.sin(yaw));
        GlStateManager.translate(-e.getX(), -(e.getY() + 0.9), -e.getZ());
        tilted.add(p.getEntityId());
    }

    private final java.util.Set<Integer> tilted = new java.util.HashSet<>();

    @SubscribeEvent
    public void onRenderPost(RenderPlayerEvent.Post e) {
        if (tilted.remove(e.getEntityPlayer().getEntityId())) GlStateManager.popMatrix();
    }

    @SubscribeEvent
    public void onWorldLast(RenderWorldLastEvent e) {
        HudRenderer.capture();
    }

    @SubscribeEvent
    public void onDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent e) {
        ClientSuitManager.clear();
    }

    @SubscribeEvent
    public void onUnload(WorldEvent.Unload e) {
        if (e.getWorld().isRemote) ClientSuitManager.clear();
    }
}
