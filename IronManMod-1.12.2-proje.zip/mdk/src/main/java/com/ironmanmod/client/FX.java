package com.ironmanmod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Random;

public class FX {
    public static final Random R = new Random();

    public static void glow(World w, double x, double y, double z, double mx, double my, double mz, int rgb, float size, int life) {
        float r = ((rgb >> 16) & 255) / 255F, g = ((rgb >> 8) & 255) / 255F, b = (rgb & 255) / 255F;
        Minecraft.getMinecraft().effectRenderer.addEffect(new ParticleGlow(w, x, y, z, mx, my, mz, r, g, b, size, life));
    }

    /** Eksene dik halka. */
    public static void ring(World w, Vec3d c, Vec3d axis, double radius, int n, int rgb, double outSpeed, float size, int life) {
        Vec3d a = axis.normalize();
        Vec3d helper = Math.abs(a.y) < 0.9 ? new Vec3d(0, 1, 0) : new Vec3d(1, 0, 0);
        Vec3d u = a.crossProduct(helper).normalize();
        Vec3d v = a.crossProduct(u).normalize();
        for (int i = 0; i < n; i++) {
            double ang = Math.PI * 2 * i / n;
            double cx = Math.cos(ang), sx = Math.sin(ang);
            Vec3d dir = u.scale(cx).add(v.scale(sx));
            Vec3d p = c.add(dir.scale(radius));
            glow(w, p.x, p.y, p.z, dir.x * outSpeed, dir.y * outSpeed, dir.z * outSpeed, rgb, size, life);
        }
    }

    public static void burst(World w, Vec3d c, int n, int rgb, double speed, float size, int life) {
        for (int i = 0; i < n; i++) {
            double x = R.nextGaussian(), y = R.nextGaussian(), z = R.nextGaussian();
            double l = Math.max(0.001, Math.sqrt(x * x + y * y + z * z));
            glow(w, c.x, c.y, c.z, x / l * speed, y / l * speed, z / l * speed, rgb, size, life);
        }
    }
}
