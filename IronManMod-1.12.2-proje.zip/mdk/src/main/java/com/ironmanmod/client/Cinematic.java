package com.ironmanmod.client;

import com.ironmanmod.ModConfig;
import com.ironmanmod.SuitData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Kamera sarsintisi, FOV, orbit kamera, letterbox ve takim giyme sinematigi. */
public class Cinematic {
    public static float shake;
    public static float orbit, orbitPrev;
    public static float lb, lbPrev;
    public static float fov, fovPrev;
    public static int suitUp, suitUpTotal;
    public static boolean cinema;
    private static int savedView = -1;
    private static float shakeTime;

    public static void shake(double amount) {
        if (!ModConfig.cinematicEffects) return;
        shake = (float) Math.min(3.0, shake + amount);
    }

    public static void startSuitUp(int ticks) {
        if (!ModConfig.cinematicEffects) return;
        suitUp = suitUpTotal = ticks;
        beginThirdPerson();
    }

    public static void toggleCinema() {
        if (!ModConfig.cinematicEffects) return;
        cinema = !cinema;
        if (cinema) beginThirdPerson();
        else endThirdPerson();
    }

    private static void beginThirdPerson() {
        Minecraft mc = Minecraft.getMinecraft();
        if (savedView < 0) savedView = mc.gameSettings.thirdPersonView;
        mc.gameSettings.thirdPersonView = 1;
    }

    private static void endThirdPerson() {
        Minecraft mc = Minecraft.getMinecraft();
        if (savedView >= 0 && !cinema && suitUp <= 0) {
            mc.gameSettings.thirdPersonView = savedView;
            savedView = -1;
            orbit = orbitPrev = 0;
        }
    }

    public static void tick(Minecraft mc, SuitData d) {
        lbPrev = lb;
        fovPrev = fov;
        orbitPrev = orbit;
        if (!ModConfig.cinematicEffects) {
            lb = fov = shake = 0;
            return;
        }
        float lbT = 0, fovT = 0;
        if (suitUp > 0) {
            suitUp--;
            float prog = 1F - suitUp / (float) Math.max(1, suitUpTotal);
            float ease = prog * prog * (3 - 2 * prog);
            orbit = 180F * (1F - ease) + (cinema ? 0 : 0);
            mc.gameSettings.thirdPersonView = 1;
            lbT = 1F;
            fovT = (float) (-12 * Math.sin(prog * Math.PI));
            if (suitUp == 0) {
                shake(1.2);
                if (!cinema) endThirdPerson();
            }
        } else if (cinema) {
            orbit += 0.45F;
            lbT = 1F;
            fovT = -6F;
        } else if (orbit != 0) {
            orbit *= 0.8F;
            if (Math.abs(orbit) < 0.5F) orbit = 0;
        }
        if (d != null && d.suit != null) {
            if (d.flying) fovT += Math.min(22F, (float) d.speed * (d.boosting ? 11F : 6F));
            if (d.unibeamCharge > 0) {
                fovT -= d.unibeamCharge * 0.45F;
                lbT = Math.max(lbT, 0.6F);
                shake = Math.max(shake, d.unibeamCharge * 0.025F);
            }
            if (d.boosting) shake = Math.max(shake, 0.22F);
        }
        lb += (lbT - lb) * 0.12F;
        fov += (fovT - fov) * 0.15F;
        shake *= 0.85F;
        if (shake < 0.01F) shake = 0;
        shakeTime += 1F;
    }

    @SubscribeEvent
    public void onCamera(EntityViewRenderEvent.CameraSetup e) {
        if (!ModConfig.cinematicEffects) return;
        float pt = (float) e.getRenderPartialTicks();
        float o = orbitPrev + (orbit - orbitPrev) * pt;
        if (o != 0) e.setYaw(e.getYaw() + o);
        if (shake > 0) {
            e.setRoll(e.getRoll() + (FX.R.nextFloat() - 0.5F) * shake * 4F);
            e.setPitch(e.getPitch() + (FX.R.nextFloat() - 0.5F) * shake * 2.5F);
            e.setYaw(e.getYaw() + (FX.R.nextFloat() - 0.5F) * shake * 2F);
        }
    }

    @SubscribeEvent
    public void onFov(EntityViewRenderEvent.FOVModifier e) {
        if (!ModConfig.cinematicEffects) return;
        float pt = (float) e.getRenderPartialTicks();
        e.setFOV(e.getFOV() + fovPrev + (fov - fovPrev) * pt);
    }

    public static void drawBars(ScaledResolution sr, float pt) {
        float l = lbPrev + (lb - lbPrev) * pt;
        if (l < 0.01F) return;
        int h = (int) (sr.getScaledHeight() * 0.11F * l);
        Gui.drawRect(0, 0, sr.getScaledWidth(), h, 0xFF000000);
        Gui.drawRect(0, sr.getScaledHeight() - h, sr.getScaledWidth(), sr.getScaledHeight(), 0xFF000000);
    }
}
