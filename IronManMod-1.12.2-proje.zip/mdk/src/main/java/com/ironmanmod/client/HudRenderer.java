package com.ironmanmod.client;

import com.ironmanmod.Feature;
import com.ironmanmod.SuitData;
import com.ironmanmod.SuitType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

/** J.A.R.V.I.S. HUD'u. */
public class HudRenderer extends Gui {
    private static final FloatBuffer MV = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer PR = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer OUT = BufferUtils.createFloatBuffer(4);
    private static final IntBuffer VP = BufferUtils.createIntBuffer(16);
    private static boolean haveMatrices;
    private float lastHealth = -1;

    public static void capture() {
        MV.clear();
        PR.clear();
        VP.clear();
        GL11.glGetFloat(GL11.GL_MODELVIEW_MATRIX, MV);
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, PR);
        GL11.glGetInteger(GL11.GL_VIEWPORT, VP);
        haveMatrices = true;
    }

    private static class Entry {
        KeyBinding key;
        String label;
        boolean on;
        String status;
        float cooldown = -1;

        Entry(KeyBinding key, String label, boolean on, String status) {
            this.key = key;
            this.label = label;
            this.on = on;
            this.status = status;
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null) return;
        ScaledResolution sr = e.getResolution();
        float pt = e.getPartialTicks();
        Cinematic.drawBars(sr, pt);

        SuitData d = ClientSuitManager.self();
        if (d == null || d.suit == null || ClientSuitManager.hudMode == 2) return;
        if (mc.gameSettings.showDebugInfo) return;

        FontRenderer fr = mc.fontRenderer;
        int w = sr.getScaledWidth(), h = sr.getScaledHeight();
        int col = d.suit.hudColor;
        boolean full = d.faceClosed && ClientSuitManager.hudMode == 0;
        float boot = Math.min(1F, (ClientSuitManager.hudBoot + pt) / 40F);
        if (!d.faceClosed) boot = 0.35F;
        int a = (int) (255 * boot);

        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);

        // hasar yanip sonmesi
        if (p.getHealth() < lastHealth && lastHealth > 0) ClientSuitManager.damageFlash = 1F;
        lastHealth = p.getHealth();

        if (full) {
            vignette(w, h, col, boot);
            compass(fr, p, w, col, a, pt);
            reticle(w, h, p, d, col, a);
            radar(fr, p, w - 62, h - 82, 46, col, a);
            targets(mc, fr, p, d, sr, col, a, pt);
            speedAlt(fr, p, d, w, h, col, a);
        }
        reactorPanel(fr, p, d, 12, 22, col, a, full);
        featureList(fr, d, w, h, col, a, full);
        if (full) jarvisLog(fr, h, col, a);
        if (boot < 1F && d.faceClosed) bootText(fr, w, h, col, boot);
        warnings(fr, d, w, h, a);

        if (ClientSuitManager.damageFlash > 0) {
            int fa = (int) (90 * ClientSuitManager.damageFlash);
            drawGradientRect(0, 0, w, h, (fa << 24) | 0xFF0000, (fa << 24) | 0xFF0000);
        }
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1F, 1F, 1F, 1F);
    }

    // ------------------------------------------------------------------ parcalar
    private void vignette(int w, int h, int col, float boot) {
        int rgb = col & 0xFFFFFF;
        int s = (int) (60 * boot) << 24 | rgb;
        int z = rgb;
        drawGradientRect(0, 0, w, 40, s, z);
        drawGradientRect(0, h - 40, w, h, z, s);
        drawGradientRect(0, 0, 30, h, s, z); // yaklasik
    }

    private void compass(FontRenderer fr, EntityPlayerSP p, int w, int col, int a, float pt) {
        float yaw = MathHelper.wrapDegrees(p.prevRotationYaw + (p.rotationYaw - p.prevRotationYaw) * pt);
        float heading = (yaw + 180F + 360F) % 360F;
        int cx = w / 2, y = 8;
        int c = (a << 24) | (col & 0xFFFFFF);
        line(cx - 100, y + 14, cx + 100, y + 14, 1F, (a / 3 << 24) | (col & 0xFFFFFF));
        String[] names = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        for (int deg = (int) heading - 60; deg <= (int) heading + 60; deg++) {
            if (deg % 5 != 0) continue;
            int dd = ((deg % 360) + 360) % 360;
            float x = cx + (deg - heading) * 1.6F;
            float edge = 1F - Math.abs(x - cx) / 100F;
            if (edge < 0) continue;
            int ca = ((int) (a * edge) << 24) | (col & 0xFFFFFF);
            boolean major = dd % 45 == 0;
            line(x, y + 14, x, y + (major ? 6 : 10), 1F, ca);
            if (major) {
                String n = names[dd / 45];
                fr.drawStringWithShadow(n, x - fr.getStringWidth(n) / 2F, y - 4, ca | 0xFF000000 & 0);
            }
        }
        fill(cx - 1, y + 15, cx + 1, y + 22, c);
        String hs = String.format("%03d", (int) heading);
        fr.drawStringWithShadow(hs, cx - fr.getStringWidth(hs) / 2F, y + 24, c);
    }

    private void reticle(int w, int h, EntityPlayerSP p, SuitData d, int col, int a) {
        int cx = w / 2, cy = h / 2;
        int c = (a / 2 << 24) | (col & 0xFFFFFF);
        circle(cx, cy, 22, 1F, c);
        circle(cx, cy, 3, 1F, (a << 24) | (col & 0xFFFFFF));
        for (int i = 0; i < 4; i++) {
            double ang = i * Math.PI / 2;
            line(cx + Math.sin(ang) * 22, cy - Math.cos(ang) * 22, cx + Math.sin(ang) * 30, cy - Math.cos(ang) * 30, 1F, c);
        }
        // egim merdiveni
        float pitch = p.rotationPitch;
        for (int ang = -30; ang <= 30; ang += 10) {
            if (ang == 0) continue;
            float y = cy + (ang - pitch) * 4F;
            if (y < cy - 70 || y > cy + 70) continue;
            float edge = 1F - Math.abs(y - cy) / 70F;
            int ca = ((int) (a * 0.6F * edge) << 24) | (col & 0xFFFFFF);
            line(cx - 50, y, cx - 30, y, 1F, ca);
            line(cx + 30, y, cx + 50, y, 1F, ca);
            String t = String.valueOf(-ang);
            Minecraft.getMinecraft().fontRenderer.drawString(t, cx + 54, (int) y - 4, ca, false);
        }
        // kilitlenme ve sarj
        if (d.unibeamCharge > 0) {
            float f = Math.min(1F, d.unibeamCharge / 35F);
            ring(cx, cy, 32, 35, 0, 360 * f, 0xFFFFFFFF);
        }
    }

    private void reactorPanel(FontRenderer fr, EntityPlayerSP p, SuitData d, int x, int y, int col, int a, boolean full) {
        int c = (a << 24) | (col & 0xFFFFFF);
        fr.drawStringWithShadow(d.suit.displayName.toUpperCase(), x, y, c | 0xFF000000 & 0);
        fr.drawString(I18n.format("ironmanmod.hud.title"), x, y + 10, (a / 2 << 24) | (col & 0xFFFFFF), false);
        float frac = d.maxEnergy <= 0 ? 0F : (float) (d.energy / d.maxEnergy);
        int ec = frac < 0.25F ? 0xFF3030 : (frac < 0.5F ? 0xFFC030 : (col & 0xFFFFFF));
        int cx = x + 32, cy = y + 56, r = 28;
        // ark reaktoru
        ring(cx, cy, r - 6, r, 0, 360, (a / 4 << 24) | 0x202020);
        ring(cx, cy, r - 6, r, 0, 360 * frac, (a << 24) | ec);
        float pulse = 0.6F + 0.4F * (float) Math.sin((p.ticksExisted) * 0.15);
        ring(cx, cy, 0, r - 12, 0, 360, ((int) (a * 0.25F * pulse) << 24) | ec);
        ring(cx, cy, 6, 8, 0, 360, ((int) (a * pulse) << 24) | 0xFFFFFF);
        String pc = (int) (frac * 100) + "%";
        fr.drawStringWithShadow(pc, cx - fr.getStringWidth(pc) / 2F, cy - 4, 0xFFFFFFFF);
        fr.drawString((int) d.energy + " / " + d.maxEnergy, x, cy + r + 6, (a << 24) | ec, false);

        if (full) {
            // zirh butunlugu
            float sum = 0;
            for (EntityEquipmentSlot sl : SuitType.ARMOR_SLOTS) {
                ItemStack st = p.getItemStackFromSlot(sl);
                if (!st.isEmpty() && st.getMaxDamage() > 0) sum += 1F - (float) st.getItemDamage() / st.getMaxDamage();
            }
            bar(fr, x, cy + r + 20, 64, I18n.format("ironmanmod.hud.integrity"), sum / 4F, col, a);
            bar(fr, x, cy + r + 34, 64, I18n.format("ironmanmod.hud.health"), p.getHealth() / p.getMaxHealth(), 0x55FF55, a);
        }
    }

    private void bar(FontRenderer fr, int x, int y, int w, String label, float f, int rgb, int a) {
        fr.drawString(label, x, y - 9, (a / 2 << 24) | 0xFFFFFF, false);
        fill(x, y, x + w, y + 3, (a / 4 << 24) | 0x000000);
        fill(x, y, x + (int) (w * MathHelper.clamp(f, 0F, 1F)), y + 3, (a << 24) | (rgb & 0xFFFFFF));
    }

    private void featureList(FontRenderer fr, SuitData d, int w, int h, int col, int a, boolean full) {
        SuitType s = d.suit;
        String on = I18n.format("ironmanmod.hud.on"), off = I18n.format("ironmanmod.hud.off");
        List<Entry> l = new ArrayList<>();
        l.add(new Entry(KeyBindings.FACE, I18n.format("ironmanmod.feature.face"), d.faceClosed, d.faceClosed ? I18n.format("ironmanmod.hud.closed") : I18n.format("ironmanmod.hud.open")));
        if (s.has(Feature.FLIGHT)) {
            l.add(new Entry(KeyBindings.FLIGHT, I18n.format("ironmanmod.feature.flight"), d.flying, d.flying ? on : off));
            l.add(new Entry(KeyBindings.HOVER, I18n.format("ironmanmod.feature.hover"), d.hover, d.hover ? on : off));
            l.add(new Entry(KeyBindings.BOOST, I18n.format("ironmanmod.feature.boost"), d.boosting, d.boosting ? on : off));
        }
        if (s.has(Feature.REPULSOR)) l.add(new Entry(KeyBindings.REPULSOR, I18n.format("ironmanmod.feature.repulsor"), d.repulsor, d.repulsor ? on : "RDY"));
        if (s.has(Feature.UNIBEAM)) {
            Entry en = new Entry(KeyBindings.UNIBEAM, I18n.format("ironmanmod.feature.unibeam"), d.unibeamCharge > 0, d.beamCooldown > 0 ? "CD" : "RDY");
            en.cooldown = d.beamCooldown / 100F;
            l.add(en);
        }
        if (s.has(Feature.MISSILES)) {
            Entry en = new Entry(KeyBindings.MISSILES, I18n.format("ironmanmod.feature.missiles"), d.missilesQueued > 0, d.missileCooldown > 0 ? "CD" : "RDY");
            en.cooldown = d.missileCooldown / 100F;
            l.add(en);
        }
        if (s.has(Feature.FLAMETHROWER)) l.add(new Entry(KeyBindings.FLAME, I18n.format("ironmanmod.feature.flamethrower"), d.flame, d.flame ? on : off));
        if (s.has(Feature.LOCKON)) l.add(new Entry(KeyBindings.LOCKON, I18n.format("ironmanmod.feature.lockon"), d.lockOn, d.lockOn ? (d.lockTarget >= 0 ? "LOCK" : on) : off));
        if (s.has(Feature.NIGHT_VISION)) l.add(new Entry(KeyBindings.VISION, I18n.format("ironmanmod.feature.night_vision"), d.nightVision, d.nightVision ? on : off));
        l.add(new Entry(KeyBindings.SUITUP, I18n.format("ironmanmod.feature.suitup"), false, "--"));
        l.add(new Entry(KeyBindings.CINEMA, I18n.format("ironmanmod.feature.cinema"), Cinematic.cinema, Cinematic.cinema ? on : off));
        l.add(new Entry(KeyBindings.HUD, I18n.format("ironmanmod.feature.hud"), true, String.valueOf(ClientSuitManager.hudMode)));

        int rowH = 12;
        int y = h / 2 - l.size() * rowH / 2;
        int boxW = 128;
        int x = w - boxW - 8;
        for (Entry e : l) {
            int rgb = e.on ? (col & 0xFFFFFF) : 0x8A8A8A;
            int bg = (a / 4 << 24);
            fill(x, y, x + boxW, y + rowH - 1, bg | 0x000000);
            fill(x, y, x + 2, y + rowH - 1, (a << 24) | rgb);
            String k = "[" + e.key.getDisplayName() + "]";
            fr.drawString(k, x + 5, y + 2, (a << 24) | 0xFFFFFF, false);
            fr.drawString(e.label, x + 30, y + 2, (a << 24) | rgb, false);
            fr.drawString(e.status, x + boxW - fr.getStringWidth(e.status) - 4, y + 2, (a << 24) | rgb, false);
            if (e.cooldown > 0) fill(x + 2, y + rowH - 2, x + 2 + (int) ((boxW - 2) * e.cooldown), y + rowH - 1, (a << 24) | 0xFFAA00);
            y += rowH;
        }
    }

    private void speedAlt(FontRenderer fr, EntityPlayerSP p, SuitData d, int w, int h, int col, int a) {
        int c = (a << 24) | (col & 0xFFFFFF);
        double kmh = d.speed * 20 * 3.6;
        String sp = String.format("%03d", (int) kmh);
        String alt = String.format("%03d", (int) p.posY);
        int y = h - 68;
        fr.drawString("SPD", w / 2 - 100, y, (a / 2 << 24) | 0xFFFFFF, false);
        fr.drawStringWithShadow(sp + " km/h", w / 2 - 100, y + 9, c);
        fr.drawString("ALT", w / 2 + 62, y, (a / 2 << 24) | 0xFFFFFF, false);
        fr.drawStringWithShadow(alt + " m", w / 2 + 62, y + 9, c);
        float sf = (float) Math.min(1.0, d.speed / (d.suit.flightSpeed * 2.4 + 0.01));
        fill(w / 2 - 100, y + 20, w / 2 - 40, y + 22, (a / 4 << 24));
        fill(w / 2 - 100, y + 20, w / 2 - 100 + (int) (60 * sf), y + 22, c);
    }

    private void radar(FontRenderer fr, EntityPlayerSP p, int cx, int cy, int r, int col, int a) {
        int c = (a << 24) | (col & 0xFFFFFF);
        ring(cx, cy, 0, r, 0, 360, (a / 6 << 24) | 0x001018);
        circle(cx, cy, r, 1F, c);
        circle(cx, cy, r / 2, 1F, (a / 3 << 24) | (col & 0xFFFFFF));
        line(cx - r, cy, cx + r, cy, 1F, (a / 4 << 24) | (col & 0xFFFFFF));
        line(cx, cy - r, cx, cy + r, 1F, (a / 4 << 24) | (col & 0xFFFFFF));
        double sweep = (p.ticksExisted * 6) % 360;
        line(cx, cy, cx + Math.sin(Math.toRadians(sweep)) * r, cy - Math.cos(Math.toRadians(sweep)) * r, 1F, (a / 2 << 24) | (col & 0xFFFFFF));
        double yaw = Math.toRadians(p.rotationYaw);
        double range = 32;
        for (Entity e : Minecraft.getMinecraft().world.loadedEntityList) {
            if (e == p || !(e instanceof EntityLivingBase)) continue;
            double dx = e.posX - p.posX, dz = e.posZ - p.posZ;
            if (dx * dx + dz * dz > range * range) continue;
            double sx = -dx * Math.cos(yaw) - dz * Math.sin(yaw);
            double sy = dx * Math.sin(yaw) - dz * Math.cos(yaw);
            int dc = e instanceof IMob ? 0xFF3030 : (e instanceof EntityPlayer ? 0x40A0FF : 0x40FF70);
            fill(cx + sx / range * r - 1, cy + sy / range * r - 1, cx + sx / range * r + 1.5, cy + sy / range * r + 1.5, (a << 24) | dc);
        }
        fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFFFFFF);
    }

    private void targets(Minecraft mc, FontRenderer fr, EntityPlayerSP p, SuitData d, ScaledResolution sr, int col, int a, float pt) {
        for (Entity e : mc.world.loadedEntityList) {
            if (!(e instanceof EntityLivingBase) || e == p || !e.isEntityAlive()) continue;
            if (!(e instanceof IMob) && e.getEntityId() != d.lockTarget) continue;
            if (e.getDistanceSq(p) > 40 * 40) continue;
            double ex = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt;
            double ey = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt + e.height / 2;
            double ez = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt;
            float[] sp = project(mc, sr, ex, ey, ez, pt);
            if (sp == null) continue;
            boolean locked = e.getEntityId() == d.lockTarget;
            int sz = locked ? 16 : 7;
            int rgb = locked ? 0xFF3030 : 0xFF9060;
            int c = (a << 24) | rgb;
            bracket(sp[0], sp[1], sz, c);
            if (locked) {
                circle(sp[0], sp[1], sz + 6 + (float) Math.sin(p.ticksExisted * 0.3) * 2, 1F, c);
                EntityLivingBase le = (EntityLivingBase) e;
                String t = le.getName() + "  " + (int) p.getDistance(e) + "m";
                fr.drawStringWithShadow(t, sp[0] + sz + 4, sp[1] - 8, c | 0);
                float f = le.getHealth() / le.getMaxHealth();
                fill((int) sp[0] + sz + 4, (int) sp[1] + 3, (int) sp[0] + sz + 44, (int) sp[1] + 5, (a / 4 << 24));
                fill((int) sp[0] + sz + 4, (int) sp[1] + 3, (int) sp[0] + sz + 4 + (int) (40 * MathHelper.clamp(f, 0F, 1F)), (int) sp[1] + 5, c);
            }
        }
    }

    private float[] project(Minecraft mc, ScaledResolution sr, double wx, double wy, double wz, float pt) {
        if (!haveMatrices) return null;
        Entity v = mc.getRenderViewEntity();
        if (v == null) return null;
        double cx = v.lastTickPosX + (v.posX - v.lastTickPosX) * pt;
        double cy = v.lastTickPosY + (v.posY - v.lastTickPosY) * pt;
        double cz = v.lastTickPosZ + (v.posZ - v.lastTickPosZ) * pt;
        OUT.clear();
        boolean ok = GLU.gluProject((float) (wx - cx), (float) (wy - cy), (float) (wz - cz), MV, PR, VP, OUT);
        if (!ok) return null;
        float z = OUT.get(2);
        if (z < 0F || z > 1F) return null;
        int f = sr.getScaleFactor();
        return new float[]{OUT.get(0) / f, (mc.displayHeight - OUT.get(1)) / f};
    }

    private void jarvisLog(FontRenderer fr, int h, int col, int a) {
        int y = h / 2 + 30;
        for (ClientSuitManager.Line l : ClientSuitManager.LOG) {
            float fade = l.age > 100 ? 1F - (l.age - 100) / 40F : 1F;
            int la = (int) (a * fade);
            if (la < 8) continue;
            int shown = Math.min(l.text.length(), l.age * 2);
            fr.drawString("> " + l.text.substring(0, shown), 14, y, (la << 24) | (col & 0xFFFFFF), false);
            y += 10;
        }
    }

    private void bootText(FontRenderer fr, int w, int h, int col, float boot) {
        String[] lines = {"J.A.R.V.I.S.", I18n.format("ironmanmod.hud.boot1"), I18n.format("ironmanmod.hud.boot2"), I18n.format("ironmanmod.hud.boot3")};
        int n = (int) (boot * lines.length * 1.3F);
        int y = h / 2 - 20;
        for (int i = 0; i < Math.min(n, lines.length); i++) {
            fr.drawStringWithShadow(lines[i], w / 2 - 70, y + i * 11, 0xFF000000 | (col & 0xFFFFFF));
        }
    }

    private void warnings(FontRenderer fr, SuitData d, int w, int h, int a) {
        if (d.maxEnergy > 0 && d.energy / d.maxEnergy < 0.15 && (System.currentTimeMillis() / 400) % 2 == 0) {
            String t = I18n.format("ironmanmod.hud.low_power");
            fr.drawStringWithShadow(t, w / 2 - fr.getStringWidth(t) / 2F, 42, 0xFFFF3030);
        }
    }

    // ------------------------------------------------------------------ cizim yardimcilari
    private static void fill(double x1, double y1, double x2, double y2, int argb) {
        Gui.drawRect((int) x1, (int) y1, (int) x2, (int) y2, argb);
    }

    private static void bracket(double cx, double cy, int s, int argb) {
        int l = Math.max(3, s / 2);
        double[][] c = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (double[] k : c) {
            double x = cx + k[0] * s, y = cy + k[1] * s;
            line(x, y, x - k[0] * l, y, 1.5F, argb);
            line(x, y, x, y - k[1] * l, 1.5F, argb);
        }
    }

    private static void line(double x1, double y1, double x2, double y2, float width, int argb) {
        float a = (argb >>> 24 & 255) / 255F, r = (argb >> 16 & 255) / 255F, g = (argb >> 8 & 255) / 255F, b = (argb & 255) / 255F;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GL11.glLineWidth(width);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        bb.pos(x1, y1, 0).color(r, g, b, a).endVertex();
        bb.pos(x2, y2, 0).color(r, g, b, a).endVertex();
        t.draw();
        GlStateManager.enableTexture2D();
    }

    private static void circle(double cx, double cy, double r, float width, int argb) {
        float a = (argb >>> 24 & 255) / 255F, rr = (argb >> 16 & 255) / 255F, g = (argb >> 8 & 255) / 255F, b = (argb & 255) / 255F;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GL11.glLineWidth(width);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i <= 48; i++) {
            double ang = Math.PI * 2 * i / 48;
            bb.pos(cx + Math.sin(ang) * r, cy - Math.cos(ang) * r, 0).color(rr, g, b, a).endVertex();
        }
        t.draw();
        GlStateManager.enableTexture2D();
    }

    /** Ust noktadan saat yonunde dolan halka/yay (derece). */
    private static void ring(double cx, double cy, double rIn, double rOut, double startDeg, double endDeg, int argb) {
        if (endDeg - startDeg < 0.5) return;
        float a = (argb >>> 24 & 255) / 255F, r = (argb >> 16 & 255) / 255F, g = (argb >> 8 & 255) / 255F, b = (argb & 255) / 255F;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(GL11.GL_TRIANGLE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        for (double d = startDeg; d <= endDeg + 3; d += 3) {
            double dd = Math.min(d, endDeg);
            double ang = Math.toRadians(dd);
            double s = Math.sin(ang), c = Math.cos(ang);
            bb.pos(cx + s * rIn, cy - c * rIn, 0).color(r, g, b, a).endVertex();
            bb.pos(cx + s * rOut, cy - c * rOut, 0).color(r, g, b, a).endVertex();
            if (dd >= endDeg) break;
        }
        t.draw();
        GlStateManager.enableTexture2D();
    }
}
