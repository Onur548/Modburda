package com.ironmanmod.client;

import com.ironmanmod.SuitData;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.EnumMap;
import java.util.Map;

/** Ozel zirh modeli: animasyonlu yuz maskesi, omuz plakalari, parlayan ark reaktoru, avuc repulsorlari, botlarda itici. */
@SideOnly(Side.CLIENT)
public class ModelIronMan extends ModelBiped {
    private static final Map<EntityEquipmentSlot, ModelIronMan> CACHE = new EnumMap<>(EntityEquipmentSlot.class);

    public static ModelIronMan get(EntityEquipmentSlot s) {
        ModelIronMan m = CACHE.get(s);
        if (m == null) {
            m = new ModelIronMan(s);
            CACHE.put(s, m);
        }
        return m;
    }

    /** Tam parlak (fullbright) cizen kutu. */
    private static class Glow extends ModelRenderer {
        Glow(ModelBase m, int u, int v) {
            super(m, u, v);
        }

        @Override
        public void render(float scale) {
            float bx = OpenGlHelper.lastBrightnessX, by = OpenGlHelper.lastBrightnessY;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240F, 240F);
            super.render(scale);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, bx, by);
        }
    }

    private ModelRenderer faceplate;

    private ModelIronMan(EntityEquipmentSlot slot) {
        super(slot == EntityEquipmentSlot.LEGS ? 0.5F : 1.0F, 0F, 64, 64);
        switch (slot) {
            case HEAD:
                faceplate = new ModelRenderer(this, 0, 32);
                faceplate.addBox(-5F, 0F, -0.5F, 10, 9, 1, 0F);
                faceplate.setRotationPoint(0F, -9F, -5.5F);
                bipedHead.addChild(faceplate);
                break;
            case CHEST: {
                ModelRenderer reactor = new Glow(this, 24, 32);
                reactor.addBox(-1.5F, 3F, -3.6F, 3, 3, 1, 0F);
                bipedBody.addChild(reactor);

                ModelRenderer rpad = new ModelRenderer(this, 0, 44);
                rpad.addBox(-4.5F, -3.8F, -3.5F, 6, 2, 7, 0F);
                bipedRightArm.addChild(rpad);
                ModelRenderer lpad = new ModelRenderer(this, 0, 44);
                lpad.mirror = true;
                lpad.addBox(-1.5F, -3.8F, -3.5F, 6, 2, 7, 0F);
                bipedLeftArm.addChild(lpad);

                ModelRenderer rpalm = new Glow(this, 24, 40);
                rpalm.addBox(-2.5F, 12.7F, -1.5F, 3, 1, 3, 0F);
                bipedRightArm.addChild(rpalm);
                ModelRenderer lpalm = new Glow(this, 24, 40);
                lpalm.mirror = true;
                lpalm.addBox(-0.5F, 12.7F, -1.5F, 3, 1, 3, 0F);
                bipedLeftArm.addChild(lpalm);
                break;
            }
            case FEET: {
                ModelRenderer rt = new Glow(this, 40, 40);
                rt.addBox(-1.5F, 7.5F, 2.7F, 3, 3, 1, 0F);
                bipedRightLeg.addChild(rt);
                ModelRenderer lt = new Glow(this, 40, 40);
                lt.mirror = true;
                lt.addBox(-1.5F, 7.5F, 2.7F, 3, 3, 1, 0F);
                bipedLeftLeg.addChild(lt);
                break;
            }
            default:
                break;
        }
    }

    @Override
    public void setLivingAnimations(EntityLivingBase e, float ls, float lsa, float pt) {
        super.setLivingAnimations(e, ls, lsa, pt);
        if (faceplate != null) {
            float open = 0F;
            if (e instanceof EntityPlayer) {
                SuitData d = ClientSuitManager.get(e.getUniqueID());
                if (d != null) open = d.faceOpen(pt);
            }
            float eased = open * open * (3F - 2F * open);
            faceplate.rotateAngleX = -2.45F * eased;
        }
    }
}
