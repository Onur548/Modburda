package com.ironmanmod.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

public class KeyBindings {
    public static final String CAT = "key.categories.ironmanmod";
    public static final KeyBinding FLIGHT = new KeyBinding("key.ironmanmod.flight", Keyboard.KEY_R, CAT);
    public static final KeyBinding FACE = new KeyBinding("key.ironmanmod.face", Keyboard.KEY_F, CAT);
    public static final KeyBinding REPULSOR = new KeyBinding("key.ironmanmod.repulsor", Keyboard.KEY_V, CAT);
    public static final KeyBinding UNIBEAM = new KeyBinding("key.ironmanmod.unibeam", Keyboard.KEY_G, CAT);
    public static final KeyBinding MISSILES = new KeyBinding("key.ironmanmod.missiles", Keyboard.KEY_B, CAT);
    public static final KeyBinding BOOST = new KeyBinding("key.ironmanmod.boost", Keyboard.KEY_X, CAT);
    public static final KeyBinding HOVER = new KeyBinding("key.ironmanmod.hover", Keyboard.KEY_Z, CAT);
    public static final KeyBinding SUITUP = new KeyBinding("key.ironmanmod.suitup", Keyboard.KEY_U, CAT);
    public static final KeyBinding VISION = new KeyBinding("key.ironmanmod.vision", Keyboard.KEY_N, CAT);
    public static final KeyBinding LOCKON = new KeyBinding("key.ironmanmod.lockon", Keyboard.KEY_K, CAT);
    public static final KeyBinding FLAME = new KeyBinding("key.ironmanmod.flame", Keyboard.KEY_Y, CAT);
    public static final KeyBinding CINEMA = new KeyBinding("key.ironmanmod.cinema", Keyboard.KEY_C, CAT);
    public static final KeyBinding HUD = new KeyBinding("key.ironmanmod.hud", Keyboard.KEY_H, CAT);

    public static void register() {
        KeyBinding[] all = {FLIGHT, FACE, REPULSOR, UNIBEAM, MISSILES, BOOST, HOVER, SUITUP, VISION, LOCKON, FLAME, CINEMA, HUD};
        for (KeyBinding k : all) ClientRegistry.registerKeyBinding(k);
    }
}
