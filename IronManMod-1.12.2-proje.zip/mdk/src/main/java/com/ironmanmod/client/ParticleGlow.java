package com.ironmanmod.client;

import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ParticleGlow extends Particle {
    private final float baseScale;

    public ParticleGlow(World w, double x, double y, double z, double mx, double my, double mz,
                        float r, float g, float b, float size, int life) {
        super(w, x, y, z);
        this.motionX = mx;
        this.motionY = my;
        this.motionZ = mz;
        this.particleRed = r;
        this.particleGreen = g;
        this.particleBlue = b;
        this.particleScale = size;
        this.baseScale = size;
        this.particleMaxAge = life;
        this.canCollide = false;
        this.setParticleTextureIndex(0);
    }

    @Override
    public int getBrightnessForRender(float pt) {
        return 0xF000F0;
    }

    @Override
    public void onUpdate() {
        prevPosX = posX;
        prevPosY = posY;
        prevPosZ = posZ;
        if (particleAge++ >= particleMaxAge) {
            setExpired();
            return;
        }
        float t = (float) particleAge / (float) particleMaxAge;
        particleAlpha = 1F - t * t;
        particleScale = baseScale * (1F - 0.6F * t);
        posX += motionX;
        posY += motionY;
        posZ += motionZ;
        motionX *= 0.9;
        motionY *= 0.9;
        motionZ *= 0.9;
    }

    @Override
    public int getFXLayer() {
        return 0;
    }
}
