package com.ironmanmod;

import com.ironmanmod.net.PacketEffect;
import com.ironmanmod.net.PacketState;

public class CommonProxy {
    public void preInit() {}
    public void init() {}
    public void handleState(PacketState m) {}
    public void handleEffect(PacketEffect m) {}
}
